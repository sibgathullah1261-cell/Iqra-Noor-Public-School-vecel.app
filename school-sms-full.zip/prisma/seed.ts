/**
 * Seed script for St. Xavier's High School SMS
 * Run with: npx tsx prisma/seed.ts
 * or: npm run db:seed (after installing tsx)
 *
 * Creates:
 * - 1 Academic Year
 * - Classes 6–10 with sections
 * - Subjects
 * - Admin, Teacher, Student, Parent users (with bcrypt hashed passwords)
 * - Sample students, attendance, fee structures
 */

import { PrismaClient, Role, Gender, AttendanceStatus, FeeType, FeeFrequency, StudentStatus, TeacherStatus } from "@prisma/client";
import * as bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seeding St. Xavier's High School database...\n");

  // Clear existing data (order matters for FKs)
  await prisma.mark.deleteMany();
  await prisma.examSubject.deleteMany();
  await prisma.examination.deleteMany();
  await prisma.assignmentSubmission.deleteMany();
  await prisma.assignment.deleteMany();
  await prisma.feePayment.deleteMany();
  await prisma.feeStructure.deleteMany();
  await prisma.studentAttendance.deleteMany();
  await prisma.teacherAttendance.deleteMany();
  await prisma.leaveApplication.deleteMany();
  await prisma.notification.deleteMany();
  await prisma.announcement.deleteMany();
  await prisma.admissionDocument.deleteMany();
  await prisma.admission.deleteMany();
  await prisma.studentDocument.deleteMany();
  await prisma.teacherSubject.deleteMany();
  await prisma.timetableSlot.deleteMany();
  await prisma.student.deleteMany();
  await prisma.section.deleteMany();
  await prisma.subject.deleteMany();
  await prisma.class.deleteMany();
  await prisma.teacher.deleteMany();
  await prisma.parent.deleteMany();
  await prisma.adminProfile.deleteMany();
  await prisma.auditLog.deleteMany();
  await prisma.user.deleteMany();
  await prisma.academicYear.deleteMany();
  await prisma.schoolSetting.deleteMany();

  const passwordHash = await bcrypt.hash("admin123", 10);
  const teacherHash = await bcrypt.hash("teacher123", 10);
  const studentHash = await bcrypt.hash("student123", 10);
  const parentHash = await bcrypt.hash("parent123", 10);

  // Academic Year
  const year = await prisma.academicYear.create({
    data: {
      name: "2026-2027",
      startDate: new Date("2026-04-01"),
      endDate: new Date("2027-03-31"),
      isCurrent: true,
    },
  });
  console.log("✓ Academic Year:", year.name);

  // Classes 6–10
  const classNames = [
    { name: "Class 6", level: 6 },
    { name: "Class 7", level: 7 },
    { name: "Class 8", level: 8 },
    { name: "Class 9", level: 9 },
    { name: "Class 10", level: 10 },
  ];

  const classes: Record<string, string> = {};
  for (const c of classNames) {
    const cls = await prisma.class.create({
      data: {
        name: c.name,
        numericLevel: c.level,
        academicYearId: year.id,
      },
    });
    classes[c.name] = cls.id;
  }
  console.log("✓ Classes created");

  // Sections for Class 10 (main demo class)
  const sectionA = await prisma.section.create({
    data: { name: "A", classId: classes["Class 10"] },
  });
  const sectionB = await prisma.section.create({
    data: { name: "B", classId: classes["Class 10"] },
  });
  await prisma.section.create({ data: { name: "A", classId: classes["Class 9"] } });
  await prisma.section.create({ data: { name: "B", classId: classes["Class 9"] } });
  console.log("✓ Sections created");

  // Subjects for Class 10
  const subjects = ["Mathematics", "Physics", "Chemistry", "English", "Hindi", "Computer Science"];
  const subjectIds: Record<string, string> = {};
  for (const name of subjects) {
    const sub = await prisma.subject.create({
      data: { name, classId: classes["Class 10"], code: name.slice(0, 3).toUpperCase() },
    });
    subjectIds[name] = sub.id;
  }
  console.log("✓ Subjects created");

  // ========== USERS ==========

  // Admin
  const adminUser = await prisma.user.create({
    data: {
      email: "admin@stxaviers.edu",
      passwordHash,
      role: Role.ADMIN,
      adminProfile: {
        create: {
          fullName: "System Administrator",
          phone: "+91-98765-00001",
          designation: "Principal / Admin",
        },
      },
    },
  });
  console.log("✓ Admin user:", adminUser.email);

  // Teacher
  const teacherUser = await prisma.user.create({
    data: {
      email: "teacher@stxaviers.edu",
      passwordHash: teacherHash,
      role: Role.TEACHER,
      teacher: {
        create: {
          employeeId: "TCH-001",
          firstName: "Anjali",
          lastName: "Mehta",
          gender: Gender.FEMALE,
          phone: "+91-98765-10001",
          email: "teacher@stxaviers.edu",
          qualification: "M.Sc. Mathematics, B.Ed.",
          specialization: "Mathematics & Physics",
          status: TeacherStatus.ACTIVE,
        },
      },
    },
    include: { teacher: true },
  });
  const teacherId = teacherUser.teacher!.id;
  console.log("✓ Teacher user:", teacherUser.email);

  // Assign teacher to subjects and class teacher of 10-A
  await prisma.teacherSubject.createMany({
    data: [
      { teacherId, subjectId: subjectIds["Mathematics"] },
      { teacherId, subjectId: subjectIds["Physics"] },
    ],
  });
  await prisma.section.update({
    where: { id: sectionA.id },
    data: { classTeacherId: teacherId },
  });

  // Parent
  const parentUser = await prisma.user.create({
    data: {
      email: "parent@stxaviers.edu",
      passwordHash: parentHash,
      role: Role.PARENT,
      parent: {
        create: {
          fatherName: "Rajesh Sharma",
          motherName: "Sunita Sharma",
          phone: "+91-98765-20001",
          email: "parent@stxaviers.edu",
          address: "45 Green Park, Knowledge City",
          occupation: "Software Engineer",
          relation: "Father",
        },
      },
    },
    include: { parent: true },
  });
  const parentId = parentUser.parent!.id;
  console.log("✓ Parent user:", parentUser.email);

  // Student
  const studentUser = await prisma.user.create({
    data: {
      email: "student@stxaviers.edu",
      passwordHash: studentHash,
      role: Role.STUDENT,
      student: {
        create: {
          admissionNumber: "SX2024-0842",
          firstName: "Aarav",
          lastName: "Sharma",
          dateOfBirth: new Date("2011-05-15"),
          gender: Gender.MALE,
          phone: "+91-98765-30001",
          email: "student@stxaviers.edu",
          address: "45 Green Park, Knowledge City",
          sectionId: sectionA.id,
          rollNumber: 15,
          parentId,
          status: StudentStatus.ACTIVE,
          admissionDate: new Date("2024-04-01"),
        },
      },
    },
    include: { student: true },
  });
  const studentId = studentUser.student!.id;
  console.log("✓ Student user:", studentUser.email);

  // Extra students for Class 10-A (for attendance demo)
  const extraStudents = [
    { first: "Priya", last: "Patel", roll: 12, gender: Gender.FEMALE },
    { first: "Rohan", last: "Verma", roll: 18, gender: Gender.MALE },
    { first: "Sneha", last: "Iyer", roll: 21, gender: Gender.FEMALE },
    { first: "Arjun", last: "Singh", roll: 7, gender: Gender.MALE },
  ];
  for (const s of extraStudents) {
    await prisma.student.create({
      data: {
        admissionNumber: `SX2024-${String(8000 + s.roll).padStart(4, "0")}`,
        firstName: s.first,
        lastName: s.last,
        dateOfBirth: new Date("2011-01-01"),
        gender: s.gender,
        sectionId: sectionA.id,
        rollNumber: s.roll,
        status: StudentStatus.ACTIVE,
      },
    });
  }
  console.log("✓ Extra demo students created");

  // Fee Structure
  await prisma.feeStructure.createMany({
    data: [
      {
        name: "Tuition Fee – Class 10",
        academicYearId: year.id,
        classId: classes["Class 10"],
        feeType: FeeType.TUITION,
        amount: 8500,
        frequency: FeeFrequency.MONTHLY,
        dueDay: 10,
      },
      {
        name: "Transport Fee",
        academicYearId: year.id,
        feeType: FeeType.TRANSPORT,
        amount: 2000,
        frequency: FeeFrequency.MONTHLY,
        dueDay: 10,
      },
      {
        name: "Examination Fee – Mid Term",
        academicYearId: year.id,
        classId: classes["Class 10"],
        feeType: FeeType.EXAMINATION,
        amount: 500,
        frequency: FeeFrequency.ONE_TIME,
      },
    ],
  });
  console.log("✓ Fee structures created");

  // Sample attendance for the main student (last 10 days)
  const today = new Date();
  for (let i = 0; i < 10; i++) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    if (d.getDay() === 0) continue; // skip Sunday
    await prisma.studentAttendance.create({
      data: {
        studentId,
        date: d,
        status: i === 3 ? AttendanceStatus.ABSENT : AttendanceStatus.PRESENT,
        remarks: i === 3 ? "Medical leave" : undefined,
      },
    });
  }
  console.log("✓ Sample attendance records created");

  // School settings
  await prisma.schoolSetting.createMany({
    data: [
      { key: "school_name", value: "St. Xavier's High School" },
      { key: "school_address", value: "123 Education Lane, Knowledge City, Maharashtra - 400001" },
      { key: "school_phone", value: "+91-22-1234-5678" },
      { key: "school_email", value: "info@stxaviers.edu" },
      { key: "academic_year", value: "2026-2027" },
    ],
  });

  // Announcement
  await prisma.announcement.create({
    data: {
      title: "Welcome to Academic Year 2026-27",
      content: "We are delighted to welcome all students and parents to the new academic year. Classes commence from 1st April 2026.",
      targetRoles: JSON.stringify(["ALL"]),
      isPublished: true,
    },
  });

  console.log("\n✅ Seed completed successfully!\n");
  console.log("Demo credentials:");
  console.log("  Admin   → admin@stxaviers.edu   / admin123");
  console.log("  Teacher → teacher@stxaviers.edu / teacher123");
  console.log("  Student → student@stxaviers.edu / student123");
  console.log("  Parent  → parent@stxaviers.edu  / parent123");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
