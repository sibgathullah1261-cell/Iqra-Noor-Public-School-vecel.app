# St. Xavier's High School — Official Website & School Management System

Professional school website + full School Management System (SMS / ERP).

**Brand colours:** Navy `#1e3a5f` · Gold `#c9a227` · White

---

## Features Implemented

### Public website
- Homepage with hero, about, vision/mission, principal message
- Academics, facilities, news, contact
- Online Admission portal (`/admissions`)
- Login portals for Parent / Student / Teacher / Admin

### Authentication
- Role-based login API (`/api/auth/login`)
- Database users with bcrypt passwords (after seed)
- Demo fallback when DB is empty
- Session stored client-side (upgrade path to NextAuth / httpOnly cookies documented)

### Dashboards
- **Admin** — stats, activity, full navigation
- **Teacher** — classes, timetable, attendance entry
- **Student** — profile, attendance %, results, fees status
- **Parent** — child overview, fees, notifications

### Core modules
| Module | Routes / APIs | Notes |
|--------|---------------|-------|
| Attendance | `/teacher/attendance`, `POST /api/attendance` | Mark P/A/L/E, upsert to DB |
| Students | `/admin/students`, `/admin/students/new`, `GET/POST /api/students` | List + create |
| Admissions | `/admissions`, `/admin/admissions`, `GET/POST/PATCH /api/admissions` | Apply + approve/reject |
| Fees & Payments | `/parent/fees`, `/api/payments/*` | Order + verify (Razorpay sandbox ready) |
| PDF documents | `/api/pdf/report-card`, `/api/pdf/fee-receipt` | Official HTML report card & receipt |
| Examinations | `/admin/exams`, `/student/results` | Publish toggle + results view |
| Notifications | `/api/notifications` | In-app + helper for email/SMS later |

---

## Quick start

```bash
cd school-sms
npm install
# optional explicit packages:
npm install prisma @prisma/client bcryptjs zod date-fns lucide-react clsx tailwind-merge razorpay
npm install -D tsx @types/bcryptjs

cp .env.example .env   # or use existing .env
npx prisma generate
npx prisma db push
npx tsx prisma/seed.ts
npm run dev
```

Open http://localhost:3000

### Demo credentials (after seed)

| Role    | Email                   | Password    |
|---------|-------------------------|-------------|
| Admin   | admin@stxaviers.edu     | admin123    |
| Teacher | teacher@stxaviers.edu   | teacher123  |
| Student | student@stxaviers.edu   | student123  |
| Parent  | parent@stxaviers.edu    | parent123   |

---

## Razorpay (production)

1. Create Razorpay account → Test keys
2. Set in `.env`:
   ```
   RAZORPAY_KEY_ID=rzp_test_...
   RAZORPAY_KEY_SECRET=...
   NEXT_PUBLIC_RAZORPAY_KEY_ID=rzp_test_...
   ```
3. Frontend opens Razorpay Checkout with `orderId` from `/api/payments/create-order`
4. On success, call `/api/payments/verify` with signature (server verifies HMAC)

Card numbers / CVV / UPI PINs are **never** stored on the school server.

---

## PDF documents

- Report card: `/api/pdf/report-card` (open in browser → Print / Save as PDF)
- Fee receipt: `/api/pdf/fee-receipt`
- Templates include school name, address, logo mark, signature lines

For binary PDFs at scale, add `@react-pdf/renderer` or Puppeteer on top of the same HTML helpers in `src/lib/pdf.ts`.

---

## Database

Prisma schema covers: Users, Students, Teachers, Parents, Classes, Sections, Subjects, Attendance, Fees, Examinations, Marks, Assignments, Admissions, Notifications, Leave, Audit logs, Settings.

SQLite for local demo. Switch to PostgreSQL by changing `provider` and `DATABASE_URL`.

---

## Security checklist (production)

- [ ] Replace localStorage session with httpOnly secure cookies (NextAuth)
- [ ] Enforce role checks on every API route / server action
- [ ] Razorpay signature verification (already implemented)
- [ ] Rate-limit login and payment endpoints
- [ ] Restrict file uploads (type, size)
- [ ] Regular DB backups
- [ ] HTTPS only

---

## Project structure (key paths)

```
prisma/schema.prisma          # Full schema
prisma/seed.ts                # Demo data
src/app/page.tsx              # Homepage
src/app/login                 # Unified login
src/app/admin|teacher|student|parent
src/app/admissions            # Public admission form
src/app/api/...               # REST APIs
src/lib/auth.ts, pdf.ts, notifications.ts, prisma.ts, utils.ts
```

---

**This is a working, professional foundation for a real school SMS.**  
Configure Razorpay keys, run the seed, and continue expanding any module as needed.

---

## Production hardening (implemented)

- **HttpOnly signed session cookie** (`sms_session`) set on login; logout clears it
- **Middleware** protects `/admin`, `/teacher`, `/student`, `/parent` by role
- **Rate limiting** on login (8 attempts / minute per IP+email)
- **Secure file upload** `/api/upload` — type whitelist, 5 MB max, random names, no path traversal
- **Email stubs** for absence, fee reminder, admission status (logs in demo; SMTP-ready)
- **Razorpay** order + HMAC signature verification
- **PDF** report card and fee receipt (print-ready official layout)

### Upgrade path still recommended for large schools

- Full NextAuth (or Auth.js) with database sessions
- Redis rate limiting for multi-instance deploys
- S3 / Cloudinary for file storage instead of local `public/uploads`
- Puppeteer or `@react-pdf/renderer` for binary PDFs
- SMS / WhatsApp via official provider APIs

---

## Best-practice integrations (this build)

### NextAuth
- Config: `src/lib/auth-options.ts`
- Route: `/api/auth/[...nextauth]`
- Credentials provider uses Prisma users + demo fallback
- JWT session carries `role`, `studentId`, `teacherId`, `parentId`

### Storage
- `STORAGE_PROVIDER=local|s3|cloudinary`
- Abstraction in `src/lib/storage`
- Upload API always applies type/size checks

### Binary PDFs
- Client: `src/lib/pdf-client.ts` (jsPDF + autotable)
- Student Results → **Download PDF Report Card**
- Server HTML versions remain for print

### Email
- `src/lib/email.ts` uses **nodemailer** when SMTP_* is set

### SMS
- `src/lib/sms.ts` supports `console` | `twilio` | `msg91`
- Absence and fee reminder helpers ready

### Session dual-mode
- Custom signed httpOnly cookie (`sms_session`) on `/api/auth/login`
- NextAuth JWT available via `/api/auth/[...nextauth]`
- Middleware role checks on dashboard routes
