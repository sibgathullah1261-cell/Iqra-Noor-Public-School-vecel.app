import { NextRequest, NextResponse } from "next/server";

const COOKIE_NAME = "sms_session";

const roleRoutes: Record<string, string[]> = {
  admin: ["/admin"],
  teacher: ["/teacher"],
  student: ["/student"],
  parent: ["/parent"],
};

function decodeRole(token: string | undefined): string | null {
  if (!token) return null;
  try {
    const [body, sig] = token.split(".");
    if (!body || !sig) return null;
    // Lightweight check in edge — full HMAC verified in API/server
    const payload = JSON.parse(atob(body.replace(/-/g, "+").replace(/_/g, "/")));
    if (!payload.exp || payload.exp < Math.floor(Date.now() / 1000)) return null;
    return String(payload.role || "").toLowerCase();
  } catch {
    return null;
  }
}

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Only protect dashboard areas
  const protectedPrefixes = ["/admin", "/teacher", "/student", "/parent"];
  const isProtected = protectedPrefixes.some(
    (p) => pathname === p || pathname.startsWith(p + "/")
  );
  if (!isProtected) return NextResponse.next();

  const token = req.cookies.get(COOKIE_NAME)?.value;
  const role = decodeRole(token);

  // Also allow localStorage-only demo: if no cookie, still allow page load
  // (client will redirect). Cookie is preferred.
  if (!role) {
    // Soft gate: redirect to login for the matching portal
    const portal = protectedPrefixes.find(
      (p) => pathname === p || pathname.startsWith(p + "/")
    );
    const roleHint = portal?.replace("/", "") || "parent";
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.searchParams.set("role", roleHint);
    // Don't hard-block if cookie missing — client dashboards also check localStorage
    // Uncomment next line for strict cookie-only mode:
    // return NextResponse.redirect(url);
    return NextResponse.next();
  }

  // Role mismatch → send to correct portal login
  for (const [r, prefixes] of Object.entries(roleRoutes)) {
    const matches = prefixes.some(
      (p) => pathname === p || pathname.startsWith(p + "/")
    );
    if (matches && role !== r) {
      const url = req.nextUrl.clone();
      url.pathname = "/login";
      url.searchParams.set("role", r);
      return NextResponse.redirect(url);
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*", "/teacher/:path*", "/student/:path*", "/parent/:path*"],
};
