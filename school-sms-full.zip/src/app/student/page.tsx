"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  GraduationCap,
  ClipboardList,
  Award,
  FileText,
  CreditCard,
  Bell,
  LogOut,
  Calendar,
  BookOpen,
  Download,
} from "lucide-react";

type Session = { role: string; email: string; name: string };

export default function StudentDashboard() {
  const router = useRouter();
  const [session, setSession] = useState<Session | null>(null);

  useEffect(() => {
    const raw = localStorage.getItem("sms_session");
    if (!raw) {
      router.replace("/login?role=student");
      return;
    }
    const s = JSON.parse(raw) as Session;
    if (s.role !== "student") {
      router.replace(`/login?role=${s.role}`);
      return;
    }
    setSession(s);
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem("sms_session");
    router.push("/login?role=student");
  };

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-8 h-8 border-2 border-emerald-500/30 border-t-emerald-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 flex">
      <aside className="w-60 bg-emerald-700 text-white flex flex-col fixed h-full">
        <div className="p-5 border-b border-white/10">
          <p className="font-semibold">Student Portal</p>
          <p className="text-xs text-white/60">St. Xavier&apos;s High School</p>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {[
            { label: "Dashboard", href: "/student", icon: GraduationCap, active: true },
            { label: "Attendance", href: "/student/attendance", icon: ClipboardList },
            { label: "Results", href: "/student/results", icon: Award },
            { label: "Assignments", href: "/student/assignments", icon: FileText },
            { label: "Fees", href: "/student/fees", icon: CreditCard },
            { label: "Timetable", href: "/student/timetable", icon: Calendar },
            { label: "Notices", href: "/student/notices", icon: Bell },
          ].map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm ${
                item.active ? "bg-white/15 font-medium" : "text-white/70 hover:bg-white/10"
              }`}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="p-3 border-t border-white/10">
          <button onClick={handleLogout} className="flex items-center gap-3 px-3 py-2.5 text-sm text-white/70 hover:text-white w-full">
            <LogOut className="w-4 h-4" /> Logout
          </button>
        </div>
      </aside>

      <main className="flex-1 ml-60">
        <header className="bg-white border-b border-slate-200 px-6 py-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xl font-bold border-2 border-emerald-300">
              AS
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-800">{session.name}</h1>
              <p className="text-sm text-slate-500">
                Admission No: SX2024-0842 • Class 10-A • Roll No: 15
              </p>
            </div>
          </div>
        </header>

        <div className="p-6 space-y-6">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: "Attendance", value: "94.2%", sub: "This month", color: "text-emerald-600" },
              { label: "Last Exam %", value: "87.5%", sub: "Mid-Term", color: "text-blue-600" },
              { label: "Pending Fees", value: "₹0", sub: "All clear", color: "text-emerald-600" },
              { label: "Assignments", value: "3", sub: "Due this week", color: "text-amber-600" },
            ].map((s, i) => (
              <div key={i} className="bg-white rounded-xl border p-5 shadow-sm">
                <p className="text-sm text-slate-500">{s.label}</p>
                <p className={`text-2xl font-bold mt-1 ${s.color}`}>{s.value}</p>
                <p className="text-xs text-slate-400 mt-1">{s.sub}</p>
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl border p-5 shadow-sm">
              <h2 className="font-semibold text-slate-800 mb-4">Recent Results</h2>
              <div className="space-y-3">
                {[
                  { exam: "Mid-Term 2026", subject: "Mathematics", marks: "88/100", grade: "A" },
                  { exam: "Mid-Term 2026", subject: "Physics", marks: "82/100", grade: "A" },
                  { exam: "Mid-Term 2026", subject: "Chemistry", marks: "91/100", grade: "A+" },
                  { exam: "Mid-Term 2026", subject: "English", marks: "85/100", grade: "A" },
                ].map((r, i) => (
                  <div key={i} className="flex items-center justify-between py-2 border-b border-slate-50 last:border-0">
                    <div>
                      <p className="text-sm font-medium">{r.subject}</p>
                      <p className="text-xs text-slate-500">{r.exam}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold">{r.marks}</p>
                      <span className="text-xs px-1.5 py-0.5 bg-emerald-50 text-emerald-700 rounded">{r.grade}</span>
                    </div>
                  </div>
                ))}
              </div>
              <Link href="/student/results" className="inline-flex items-center gap-1 text-sm text-emerald-700 font-medium mt-4 hover:underline">
                <Download className="w-4 h-4" /> Download full report card
              </Link>
            </div>

            <div className="bg-white rounded-xl border p-5 shadow-sm">
              <h2 className="font-semibold text-slate-800 mb-4">Upcoming</h2>
              <ul className="space-y-3">
                {[
                  { title: "Physics Assignment due", date: "14 Nov 2026", type: "Assignment" },
                  { title: "Unit Test – Chemistry", date: "18 Nov 2026", type: "Exam" },
                  { title: "Parent-Teacher Meeting", date: "22 Nov 2026", type: "Event" },
                  { title: "Sports Day", date: "28 Nov 2026", type: "Event" },
                ].map((u, i) => (
                  <li key={i} className="flex gap-3 items-start">
                    <div className="w-2 h-2 rounded-full bg-emerald-500 mt-1.5" />
                    <div>
                      <p className="text-sm font-medium">{u.title}</p>
                      <p className="text-xs text-slate-500">{u.date} • {u.type}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
