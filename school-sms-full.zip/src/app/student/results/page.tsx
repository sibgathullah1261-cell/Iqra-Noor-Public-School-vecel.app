"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Award, ArrowLeft, LogOut, Download } from "lucide-react";
import { downloadReportCardPDF } from "@/lib/pdf-client";

type Session = { role: string; email: string; name: string };

const results = [
  { subject: "Mathematics", max: 100, obtained: 88, grade: "A" },
  { subject: "Physics", max: 100, obtained: 82, grade: "A" },
  { subject: "Chemistry", max: 100, obtained: 91, grade: "A+" },
  { subject: "English", max: 100, obtained: 85, grade: "A" },
  { subject: "Hindi", max: 100, obtained: 78, grade: "B+" },
  { subject: "Computer Science", max: 100, obtained: 94, grade: "A+" },
];

export default function StudentResultsPage() {
  const router = useRouter();
  const [session, setSession] = useState<Session | null>(null);

  useEffect(() => {
    const raw = localStorage.getItem("sms_session");
    if (!raw) {
      router.replace("/login?role=student");
      return;
    }
    const s = JSON.parse(raw) as Session;
    if (s.role !== "student") {
      router.replace(`/login?role=${s.role}`);
      return;
    }
    setSession(s);
  }, [router]);

  const totalMax = results.reduce((s, r) => s + r.max, 0);
  const totalObtained = results.reduce((s, r) => s + r.obtained, 0);
  const percentage = Math.round((totalObtained / totalMax) * 1000) / 10;

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-8 h-8 border-2 border-emerald-500/30 border-t-emerald-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="bg-emerald-700 text-white px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/student" className="p-2 hover:bg-white/10 rounded-lg">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-lg font-semibold flex items-center gap-2">
              <Award className="w-5 h-5" />
              Examination Results
            </h1>
            <p className="text-sm text-white/70">Mid-Term Examination 2026</p>
          </div>
        </div>
        <button
          onClick={() => {
            localStorage.removeItem("sms_session");
            router.push("/login?role=student");
          }}
          className="flex items-center gap-2 text-sm text-white/80 hover:text-white"
        >
          <LogOut className="w-4 h-4" /> Logout
        </button>
      </header>

      <main className="max-w-3xl mx-auto p-6 space-y-6">
        {/* Summary */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-sm text-slate-500">Student</p>
              <p className="text-lg font-semibold text-slate-900">{session.name}</p>
              <p className="text-sm text-slate-500">Class 10-A • Roll 15 • SX2024-0842</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-slate-500">Overall Percentage</p>
              <p className="text-3xl font-bold text-emerald-600">{percentage}%</p>
              <p className="text-sm text-slate-500">
                {totalObtained} / {totalMax} • Grade:{" "}
                <span className="font-semibold text-emerald-700">
                  {percentage >= 90 ? "A+" : percentage >= 80 ? "A" : "B+"}
                </span>
              </p>
            </div>
          </div>
        </div>

        {/* Subject marks */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-5 py-3 border-b border-slate-100 font-medium text-slate-800">
            Subject-wise Marks
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-500 bg-slate-50 border-b border-slate-100">
                <th className="px-5 py-3 font-medium">Subject</th>
                <th className="px-5 py-3 font-medium">Max</th>
                <th className="px-5 py-3 font-medium">Obtained</th>
                <th className="px-5 py-3 font-medium">Grade</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {results.map((r) => (
                <tr key={r.subject} className="hover:bg-slate-50">
                  <td className="px-5 py-3 font-medium text-slate-800">{r.subject}</td>
                  <td className="px-5 py-3">{r.max}</td>
                  <td className="px-5 py-3 font-semibold">{r.obtained}</td>
                  <td className="px-5 py-3">
                    <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded text-xs font-medium">
                      {r.grade}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-slate-50 font-semibold">
                <td className="px-5 py-3">Total</td>
                <td className="px-5 py-3">{totalMax}</td>
                <td className="px-5 py-3">{totalObtained}</td>
                <td className="px-5 py-3">{percentage}%</td>
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="flex justify-center gap-3">
          <button
            type="button"
            onClick={() =>
              downloadReportCardPDF({
                studentName: session.name,
                admissionNumber: "SX2024-0842",
                className: "Class 10",
                section: "A",
                rollNumber: 15,
                examName: "Mid-Term Examination 2026",
                academicYear: "2026-2027",
                subjects: results,
                percentage,
                overallGrade: percentage >= 90 ? "A+" : percentage >= 80 ? "A" : "B+",
              })
            }
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#1e3a5f] text-white rounded-lg text-sm font-medium hover:bg-[#2a4a6f] shadow-sm"
          >
            <Download className="w-4 h-4" />
            Download PDF Report Card
          </button>
          <a
            href="/api/pdf/report-card?name=Aarav%20Sharma&admission=SX2024-0842"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-5 py-2.5 border border-slate-300 rounded-lg text-sm font-medium hover:bg-white bg-white shadow-sm"
          >
            Printable Version
          </a>
          <button
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 px-5 py-2.5 border border-slate-300 rounded-lg text-sm font-medium hover:bg-white bg-white shadow-sm"
          >
            Print This Page
          </button>
        </div>

        <p className="text-xs text-slate-400 text-center">
          Official report cards with school logo and principal signature are generated as PDF after result publication by the administration.
        </p>
      </main>
    </div>
  );
}
