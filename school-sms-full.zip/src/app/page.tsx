import Link from "next/link";
import {
  GraduationCap,
  Users,
  BookOpen,
  Award,
  Building2,
  Calendar,
  Phone,
  Mail,
  MapPin,
  ChevronRight,
  LogIn,
  UserPlus,
  CreditCard,
  Bell,
  School,
  Target,
  Eye,
  Heart,
} from "lucide-react";

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Top Bar */}
      <div className="bg-[#1e3a5f] text-white text-sm">
        <div className="max-w-7xl mx-auto px-4 py-2 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5" />
              +91-22-1234-5678
            </span>
            <span className="hidden sm:flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5" />
              info@stxaviers.edu
            </span>
          </div>
          <div className="flex items-center gap-3">
            <Link
              href="/login?role=parent"
              className="hover:text-[#c9a227] transition"
            >
              Parent Login
            </Link>
            <span className="text-white/40">|</span>
            <Link
              href="/login?role=student"
              className="hover:text-[#c9a227] transition"
            >
              Student Login
            </Link>
            <span className="text-white/40">|</span>
            <Link
              href="/login?role=teacher"
              className="hover:text-[#c9a227] transition"
            >
              Teacher Login
            </Link>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <header className="sticky top-0 z-50 bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16 md:h-20">
            <Link href="/" className="flex items-center gap-3">
              <div className="w-12 h-12 md:w-14 md:h-14 rounded-full bg-[#1e3a5f] flex items-center justify-center text-white font-bold text-xl border-2 border-[#c9a227]">
                SX
              </div>
              <div>
                <h1 className="text-lg md:text-xl font-bold text-[#1e3a5f] leading-tight font-heading">
                  St. Xavier&apos;s High School
                </h1>
                <p className="text-xs text-slate-500 hidden sm:block">
                  Excellence in Education since 1985
                </p>
              </div>
            </Link>

            <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-700">
              <Link href="#about" className="hover:text-[#1e3a5f]">
                About
              </Link>
              <Link href="#academics" className="hover:text-[#1e3a5f]">
                Academics
              </Link>
              <Link href="#facilities" className="hover:text-[#1e3a5f]">
                Facilities
              </Link>
              <Link href="/admissions" className="hover:text-[#1e3a5f]">
                Admissions
              </Link>
              <Link href="#news" className="hover:text-[#1e3a5f]">
                News & Events
              </Link>
              <Link href="#contact" className="hover:text-[#1e3a5f]">
                Contact
              </Link>
            </nav>

            <div className="flex items-center gap-2">
              <Link
                href="/login?role=admin"
                className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-[#1e3a5f] border border-[#1e3a5f] rounded-md hover:bg-[#1e3a5f] hover:text-white transition"
              >
                <LogIn className="w-4 h-4" />
                Admin
              </Link>
              <Link
                href="/admissions"
                className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-[#c9a227] rounded-md hover:bg-[#b8911f] transition shadow-sm"
              >
                Apply Now
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#1e3a5f] via-[#2a4a6f] to-[#1e3a5f] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-72 h-72 bg-[#c9a227] rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-20 w-96 h-96 bg-white rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 py-16 md:py-24 lg:py-32">
          <div className="max-w-3xl">
            <p className="text-[#c9a227] font-semibold tracking-wider uppercase text-sm mb-3 animate-fade-in-up">
              Welcome to St. Xavier&apos;s
            </p>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6 font-heading animate-fade-in-up delay-100">
              Nurturing Minds,
              <br />
              Building Futures
            </h2>
            <p className="text-lg text-white/85 mb-8 max-w-xl animate-fade-in-up delay-200">
              A premier educational institution committed to academic excellence,
              character formation, and holistic development of every student.
            </p>
            <div className="flex flex-wrap gap-3 animate-fade-in-up delay-300">
              <Link
                href="/admissions"
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#c9a227] text-[#1e3a5f] font-semibold rounded-lg hover:bg-[#d4b02e] transition shadow-lg"
              >
                <UserPlus className="w-5 h-5" />
                Online Admission
              </Link>
              <Link
                href="/login?role=parent"
                className="inline-flex items-center gap-2 px-6 py-3 bg-white/10 backdrop-blur border border-white/30 text-white font-semibold rounded-lg hover:bg-white/20 transition"
              >
                <CreditCard className="w-5 h-5" />
                Pay Fees
              </Link>
              <Link
                href="#about"
                className="inline-flex items-center gap-2 px-6 py-3 text-white font-medium hover:text-[#c9a227] transition"
              >
                Learn More
                <ChevronRight className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Stats */}
      <section className="bg-white border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 py-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { icon: Users, label: "Students", value: "2,400+" },
              { icon: GraduationCap, label: "Teachers", value: "120+" },
              { icon: Award, label: "Years of Excellence", value: "40+" },
              { icon: BookOpen, label: "Academic Programs", value: "15+" },
            ].map((stat, i) => (
              <div
                key={i}
                className="flex items-center gap-4 p-4 rounded-xl bg-slate-50 hover:bg-slate-100 transition"
              >
                <div className="w-12 h-12 rounded-lg bg-[#1e3a5f]/10 flex items-center justify-center text-[#1e3a5f]">
                  <stat.icon className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-[#1e3a5f]">
                    {stat.value}
                  </p>
                  <p className="text-sm text-slate-500">{stat.label}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About / Vision Mission */}
      <section id="about" className="py-16 md:py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#1e3a5f] font-heading mb-3">
              About Our School
            </h2>
            <div className="w-20 h-1 bg-[#c9a227] mx-auto rounded-full" />
          </div>

          <div className="grid md:grid-cols-2 gap-10 items-center mb-16">
            <div>
              <h3 className="text-2xl font-semibold text-[#1e3a5f] mb-4 font-heading">
                Our Legacy
              </h3>
              <p className="text-slate-600 leading-relaxed mb-4">
                Founded in 1985, St. Xavier&apos;s High School has been a beacon
                of quality education in the region. With a rich tradition of
                academic excellence and holistic development, we have nurtured
                thousands of students who have gone on to excel in various
                fields.
              </p>
              <p className="text-slate-600 leading-relaxed">
                Our campus spans over 15 acres and offers state-of-the-art
                facilities, experienced faculty, and a supportive environment
                that encourages curiosity, creativity, and character.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
                <Eye className="w-8 h-8 text-[#c9a227] mb-3" />
                <h4 className="font-semibold text-[#1e3a5f] mb-2">Vision</h4>
                <p className="text-sm text-slate-600">
                  To be a leading institution that develops compassionate,
                  competent, and confident global citizens.
                </p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
                <Target className="w-8 h-8 text-[#c9a227] mb-3" />
                <h4 className="font-semibold text-[#1e3a5f] mb-2">Mission</h4>
                <p className="text-sm text-slate-600">
                  Provide holistic education that nurtures intellectual,
                  emotional, physical, and spiritual growth.
                </p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 col-span-2">
                <Heart className="w-8 h-8 text-[#c9a227] mb-3" />
                <h4 className="font-semibold text-[#1e3a5f] mb-2">
                  Core Values
                </h4>
                <p className="text-sm text-slate-600">
                  Integrity • Excellence • Respect • Compassion • Innovation •
                  Responsibility
                </p>
              </div>
            </div>
          </div>

          {/* Principal's Message */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-8 md:p-10">
            <div className="flex flex-col md:flex-row gap-8 items-start">
              <div className="w-28 h-28 rounded-full bg-[#1e3a5f] flex items-center justify-center text-white text-3xl font-bold flex-shrink-0 border-4 border-[#c9a227]">
                PR
              </div>
              <div>
                <h3 className="text-xl font-semibold text-[#1e3a5f] font-heading mb-1">
                  Principal&apos;s Message
                </h3>
                <p className="text-sm text-[#c9a227] font-medium mb-4">
                  Dr. Priya Sharma, M.A., B.Ed., Ph.D.
                </p>
                <p className="text-slate-600 leading-relaxed italic">
                  &ldquo;Education is not merely the filling of a vessel, but the
                  lighting of a fire. At St. Xavier&apos;s, we strive to ignite
                  the curiosity and passion for learning in every child. Our
                  dedicated team of educators works tirelessly to create an
                  environment where students can discover their potential and
                  grow into responsible, confident individuals ready to face the
                  challenges of tomorrow.&rdquo;
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Academics */}
      <section id="academics" className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#1e3a5f] font-heading mb-3">
              Academic Programmes
            </h2>
            <div className="w-20 h-1 bg-[#c9a227] mx-auto rounded-full" />
            <p className="mt-4 text-slate-600 max-w-2xl mx-auto">
              From foundational years to higher secondary, we offer a
              comprehensive curriculum aligned with national standards.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                title: "Primary (I–V)",
                desc: "Strong foundation in literacy, numeracy, and life skills through activity-based learning.",
              },
              {
                title: "Middle (VI–VIII)",
                desc: "Expanded curriculum with science, languages, and introduction to critical thinking.",
              },
              {
                title: "Secondary (IX–X)",
                desc: "Board examination preparation with balanced academic and co-curricular focus.",
              },
              {
                title: "Senior Secondary (XI–XII)",
                desc: "Streams in Science, Commerce & Humanities with career guidance and competitive exam support.",
              },
            ].map((prog, i) => (
              <div
                key={i}
                className="group p-6 rounded-xl border border-slate-200 hover:border-[#c9a227] hover:shadow-md transition bg-white"
              >
                <div className="w-10 h-10 rounded-lg bg-[#1e3a5f] text-white flex items-center justify-center font-bold mb-4 group-hover:bg-[#c9a227] group-hover:text-[#1e3a5f] transition">
                  {i + 1}
                </div>
                <h3 className="font-semibold text-[#1e3a5f] mb-2">
                  {prog.title}
                </h3>
                <p className="text-sm text-slate-600">{prog.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Facilities */}
      <section id="facilities" className="py-16 md:py-24 bg-[#1e3a5f] text-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold font-heading mb-3">
              Campus & Facilities
            </h2>
            <div className="w-20 h-1 bg-[#c9a227] mx-auto rounded-full" />
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: Building2, title: "Smart Classrooms", desc: "Interactive boards and digital learning tools in every classroom." },
              { icon: BookOpen, title: "Library & Resource Centre", desc: "Over 25,000 books, digital resources, and quiet study spaces." },
              { icon: School, title: "Science & Computer Labs", desc: "Well-equipped laboratories for Physics, Chemistry, Biology & IT." },
              { icon: Users, title: "Sports Complex", desc: "Football ground, basketball court, indoor sports hall and athletics track." },
              { icon: Award, title: "Auditorium", desc: "500-seat auditorium for cultural programmes and assemblies." },
              { icon: Heart, title: "Health & Counselling", desc: "On-campus clinic and professional student counselling services." },
            ].map((f, i) => (
              <div
                key={i}
                className="flex gap-4 p-5 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition"
              >
                <div className="w-12 h-12 rounded-lg bg-[#c9a227]/20 flex items-center justify-center text-[#c9a227] flex-shrink-0">
                  <f.icon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">{f.title}</h3>
                  <p className="text-sm text-white/70">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* News & Events */}
      <section id="news" className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-[#1e3a5f] font-heading mb-3">
                News & Announcements
              </h2>
              <div className="w-20 h-1 bg-[#c9a227] rounded-full" />
            </div>
            <Link
              href="/notices"
              className="text-[#1e3a5f] font-medium hover:text-[#c9a227] flex items-center gap-1"
            >
              View all notices
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                date: "10 Nov 2026",
                title: "Admission Open for Academic Year 2027-28",
                tag: "Admissions",
              },
              {
                date: "05 Nov 2026",
                title: "Annual Sports Day – Registration Now Open",
                tag: "Events",
              },
              {
                date: "01 Nov 2026",
                title: "Mid-Term Examination Schedule Published",
                tag: "Exams",
              },
            ].map((news, i) => (
              <article
                key={i}
                className="group p-6 rounded-xl border border-slate-200 hover:border-[#c9a227] hover:shadow-md transition bg-white"
              >
                <div className="flex items-center gap-2 text-xs text-slate-500 mb-3">
                  <Calendar className="w-3.5 h-3.5" />
                  {news.date}
                  <span className="px-2 py-0.5 bg-[#1e3a5f]/10 text-[#1e3a5f] rounded-full font-medium">
                    {news.tag}
                  </span>
                </div>
                <h3 className="font-semibold text-[#1e3a5f] group-hover:text-[#c9a227] transition mb-2">
                  {news.title}
                </h3>
                <Link
                  href="#"
                  className="text-sm text-[#1e3a5f] font-medium inline-flex items-center gap-1"
                >
                  Read more
                  <ChevronRight className="w-3.5 h-3.5" />
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Portal CTA */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-[#1e3a5f] font-heading mb-3">
              School Management Portals
            </h2>
            <p className="text-slate-600">
              Secure access for parents, students, teachers and administration
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {[
              {
                role: "Parent",
                href: "/login?role=parent",
                color: "bg-blue-600",
                desc: "Attendance, fees, results & more",
              },
              {
                role: "Student",
                href: "/login?role=student",
                color: "bg-emerald-600",
                desc: "Marks, assignments & timetable",
              },
              {
                role: "Teacher",
                href: "/login?role=teacher",
                color: "bg-violet-600",
                desc: "Attendance, marks & class tools",
              },
              {
                role: "Administration",
                href: "/login?role=admin",
                color: "bg-[#1e3a5f]",
                desc: "Full school management control",
              },
            ].map((p, i) => (
              <Link
                key={i}
                href={p.href}
                className="group flex flex-col items-center text-center p-6 rounded-xl bg-white border border-slate-200 hover:shadow-lg hover:border-[#c9a227] transition"
              >
                <div
                  className={`w-14 h-14 rounded-full ${p.color} text-white flex items-center justify-center mb-4 group-hover:scale-110 transition`}
                >
                  <LogIn className="w-6 h-6" />
                </div>
                <h3 className="font-semibold text-[#1e3a5f] mb-1">
                  {p.role} Login
                </h3>
                <p className="text-sm text-slate-500">{p.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-[#1e3a5f] font-heading mb-3">
              Contact Us
            </h2>
            <div className="w-20 h-1 bg-[#c9a227] mx-auto rounded-full" />
          </div>
          <div className="grid md:grid-cols-2 gap-10">
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-lg bg-[#1e3a5f]/10 flex items-center justify-center text-[#1e3a5f] flex-shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#1e3a5f]">Address</h4>
                  <p className="text-slate-600 text-sm mt-1">
                    123 Education Lane, Knowledge City,
                    <br />
                    Maharashtra – 400001, India
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-lg bg-[#1e3a5f]/10 flex items-center justify-center text-[#1e3a5f] flex-shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#1e3a5f]">Phone</h4>
                  <p className="text-slate-600 text-sm mt-1">
                    +91-22-1234-5678
                    <br />
                    +91-22-1234-5679 (Admissions)
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-lg bg-[#1e3a5f]/10 flex items-center justify-center text-[#1e3a5f] flex-shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#1e3a5f]">Email</h4>
                  <p className="text-slate-600 text-sm mt-1">
                    info@stxaviers.edu
                    <br />
                    admissions@stxaviers.edu
                  </p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-lg bg-[#1e3a5f]/10 flex items-center justify-center text-[#1e3a5f] flex-shrink-0">
                  <Bell className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-[#1e3a5f]">Office Hours</h4>
                  <p className="text-slate-600 text-sm mt-1">
                    Monday – Friday: 8:00 AM – 4:00 PM
                    <br />
                    Saturday: 8:00 AM – 12:30 PM
                  </p>
                </div>
              </div>
            </div>
            <div className="rounded-xl overflow-hidden border border-slate-200 bg-slate-100 h-80 flex items-center justify-center">
              <div className="text-center text-slate-500">
                <MapPin className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p className="text-sm">Google Maps Embed</p>
                <p className="text-xs mt-1">
                  (Add your Google Maps embed URL in production)
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0f2744] text-white">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 rounded-full bg-[#c9a227] flex items-center justify-center text-[#1e3a5f] font-bold">
                  SX
                </div>
                <span className="font-semibold">St. Xavier&apos;s High School</span>
              </div>
              <p className="text-sm text-white/70 leading-relaxed">
                Empowering students with knowledge, values and skills for a
                brighter future since 1985.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-[#c9a227]">Quick Links</h4>
              <ul className="space-y-2 text-sm text-white/80">
                <li>
                  <Link href="#about" className="hover:text-white">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#academics" className="hover:text-white">
                    Academics
                  </Link>
                </li>
                <li>
                  <Link href="/admissions" className="hover:text-white">
                    Admissions
                  </Link>
                </li>
                <li>
                  <Link href="#contact" className="hover:text-white">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-[#c9a227]">Portals</h4>
              <ul className="space-y-2 text-sm text-white/80">
                <li>
                  <Link href="/login?role=parent" className="hover:text-white">
                    Parent Portal
                  </Link>
                </li>
                <li>
                  <Link href="/login?role=student" className="hover:text-white">
                    Student Portal
                  </Link>
                </li>
                <li>
                  <Link href="/login?role=teacher" className="hover:text-white">
                    Teacher Portal
                  </Link>
                </li>
                <li>
                  <Link href="/login?role=admin" className="hover:text-white">
                    Admin Portal
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-[#c9a227]">
                Important Links
              </h4>
              <ul className="space-y-2 text-sm text-white/80">
                <li>
                  <Link href="/admissions" className="hover:text-white">
                    Online Admission
                  </Link>
                </li>
                <li>
                  <Link href="/login?role=parent" className="hover:text-white">
                    Fee Payment
                  </Link>
                </li>
                <li>
                  <Link href="/notices" className="hover:text-white">
                    Notices & Circulars
                  </Link>
                </li>
                <li>
                  <Link href="/calendar" className="hover:text-white">
                    Academic Calendar
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/10 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4 text-sm text-white/60">
            <p>
              © {new Date().getFullYear()} St. Xavier&apos;s High School. All
              rights reserved.
            </p>
            <p className="text-xs">
              School Management System • Demo Environment
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
