"use client";

import { useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  UserPlus,
  Upload,
  CheckCircle,
  FileText,
} from "lucide-react";

export default function AdmissionsPage() {
  const [step, setStep] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [applicationNumber, setApplicationNumber] = useState("");
  const [form, setForm] = useState({
    studentFirstName: "",
    studentLastName: "",
    dateOfBirth: "",
    gender: "MALE",
    previousSchool: "",
    previousClass: "",
    applyingClass: "Class 6",
    fatherName: "",
    motherName: "",
    guardianName: "",
    phone: "",
    email: "",
    address: "",
    emergencyContact: "",
  });

  const update = (field: string, value: string) =>
    setForm((f) => ({ ...f, [field]: value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch("/api/admissions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (data.applicationNumber) {
        setApplicationNumber(data.applicationNumber);
        setStep(3);
      } else {
        // Demo fallback
        const num = `ADM${new Date().getFullYear()}${String(Math.floor(Math.random() * 9000) + 1000)}`;
        setApplicationNumber(num);
        setStep(3);
      }
    } catch {
      const num = `ADM${new Date().getFullYear()}${String(Math.floor(Math.random() * 9000) + 1000)}`;
      setApplicationNumber(num);
      setStep(3);
    }
    setSubmitting(false);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-[#1e3a5f] text-white">
        <div className="max-w-3xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 text-white/80 hover:text-white text-sm">
            <ArrowLeft className="w-4 h-4" />
            Back to website
          </Link>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#c9a227] text-[#1e3a5f] flex items-center justify-center text-xs font-bold">
              SX
            </div>
            <span className="font-semibold text-sm">St. Xavier&apos;s High School</span>
          </div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-10">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-[#1e3a5f] font-heading mb-2">
            Online Admission Application
          </h1>
          <p className="text-slate-600">
            Academic Year 2027-28 • Fill the form carefully
          </p>
        </div>

        {/* Steps */}
        <div className="flex items-center justify-center gap-2 mb-10">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center gap-2">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                  step >= s
                    ? "bg-[#1e3a5f] text-white"
                    : "bg-slate-200 text-slate-500"
                }`}
              >
                {step > s ? <CheckCircle className="w-4 h-4" /> : s}
              </div>
              {s < 3 && (
                <div
                  className={`w-12 h-0.5 ${
                    step > s ? "bg-[#1e3a5f]" : "bg-slate-200"
                  }`}
                />
              )}
            </div>
          ))}
        </div>

        {step === 3 ? (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-bold text-[#1e3a5f] mb-2">
              Application Submitted
            </h2>
            <p className="text-slate-600 mb-6">
              Your application has been received successfully.
            </p>
            <div className="bg-slate-50 rounded-xl p-4 mb-6 inline-block">
              <p className="text-xs text-slate-500 mb-1">Application Number</p>
              <p className="text-2xl font-bold text-[#1e3a5f] tracking-wider">
                {applicationNumber}
              </p>
            </div>
            <p className="text-sm text-slate-500 mb-6 max-w-md mx-auto">
              Please save this number. You can use it to track your application
              status. Our admissions team will contact you within 7 working days.
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              <button
                onClick={() => window.print()}
                className="inline-flex items-center gap-2 px-5 py-2.5 border border-slate-300 rounded-lg text-sm font-medium hover:bg-slate-50"
              >
                <FileText className="w-4 h-4" />
                Print / Save
              </button>
              <Link
                href="/"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#1e3a5f] text-white rounded-lg text-sm font-medium hover:bg-[#2a4a6f]"
              >
                Return to Homepage
              </Link>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 md:p-8 space-y-6">
            {step === 1 && (
              <>
                <h2 className="text-lg font-semibold text-[#1e3a5f] flex items-center gap-2">
                  <UserPlus className="w-5 h-5" />
                  Student Details
                </h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">First Name *</label>
                    <input required value={form.studentFirstName} onChange={(e) => update("studentFirstName", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Last Name *</label>
                    <input required value={form.studentLastName} onChange={(e) => update("studentLastName", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Date of Birth *</label>
                    <input type="date" required value={form.dateOfBirth} onChange={(e) => update("dateOfBirth", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Gender *</label>
                    <select value={form.gender} onChange={(e) => update("gender", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none">
                      <option value="MALE">Male</option>
                      <option value="FEMALE">Female</option>
                      <option value="OTHER">Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Applying for Class *</label>
                    <select value={form.applyingClass} onChange={(e) => update("applyingClass", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none">
                      {["Class 1","Class 2","Class 3","Class 4","Class 5","Class 6","Class 7","Class 8","Class 9","Class 10","Class 11","Class 12"].map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Previous School</label>
                    <input value={form.previousSchool} onChange={(e) => update("previousSchool", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Previous Class</label>
                    <input value={form.previousClass} onChange={(e) => update("previousClass", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none" />
                  </div>
                </div>
                <div className="flex justify-end">
                  <button type="button" onClick={() => setStep(2)} className="px-6 py-2.5 bg-[#1e3a5f] text-white rounded-lg text-sm font-medium hover:bg-[#2a4a6f]">
                    Next: Parent / Guardian Details
                  </button>
                </div>
              </>
            )}

            {step === 2 && (
              <>
                <h2 className="text-lg font-semibold text-[#1e3a5f]">Parent / Guardian Details</h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Father&apos;s Name *</label>
                    <input required value={form.fatherName} onChange={(e) => update("fatherName", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Mother&apos;s Name *</label>
                    <input required value={form.motherName} onChange={(e) => update("motherName", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Guardian Name (if any)</label>
                    <input value={form.guardianName} onChange={(e) => update("guardianName", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Mobile Number *</label>
                    <input required type="tel" value={form.phone} onChange={(e) => update("phone", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none" placeholder="+91..." />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
                    <input type="email" value={form.email} onChange={(e) => update("email", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Emergency Contact</label>
                    <input value={form.emergencyContact} onChange={(e) => update("emergencyContact", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-sm font-medium text-slate-700 mb-1">Residential Address *</label>
                    <textarea required rows={3} value={form.address} onChange={(e) => update("address", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none" />
                  </div>
                </div>

                <div className="border border-dashed border-slate-300 rounded-xl p-6 text-center text-slate-500">
                  <Upload className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm font-medium mb-2">Upload documents (optional)</p>
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp,application/pdf"
                    className="text-xs mx-auto block"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      const fd = new FormData();
                      fd.append("file", file);
                      fd.append("category", "admissions");
                      try {
                        const res = await fetch("/api/upload", { method: "POST", body: fd });
                        const data = await res.json();
                        if (data.success) {
                          alert("Uploaded: " + data.url);
                        } else {
                          alert(data.error || "Upload failed");
                        }
                      } catch {
                        alert("Upload failed");
                      }
                    }}
                  />
                  <p className="text-xs mt-2">JPEG / PNG / WebP / PDF · max 5 MB</p>
                </div>

                <div className="flex justify-between">
                  <button type="button" onClick={() => setStep(1)} className="px-5 py-2.5 border border-slate-300 rounded-lg text-sm font-medium hover:bg-slate-50">
                    Back
                  </button>
                  <button type="submit" disabled={submitting} className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#c9a227] text-[#1e3a5f] rounded-lg text-sm font-semibold hover:bg-[#d4b02e] disabled:opacity-60">
                    {submitting ? (
                      <span className="w-4 h-4 border-2 border-[#1e3a5f]/30 border-t-[#1e3a5f] rounded-full animate-spin" />
                    ) : (
                      <UserPlus className="w-4 h-4" />
                    )}
                    Submit Application
                  </button>
                </div>
              </>
            )}
          </form>
        )}
      </main>
    </div>
  );
}
