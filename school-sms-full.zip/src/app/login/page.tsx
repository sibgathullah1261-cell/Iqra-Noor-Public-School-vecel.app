"use client";

import { useState, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import {
  LogIn,
  Eye,
  EyeOff,
  GraduationCap,
  Users,
  BookOpen,
  Shield,
  ArrowLeft,
} from "lucide-react";

const roleConfig = {
  admin: {
    title: "Administration Login",
    subtitle: "Full control over school operations",
    icon: Shield,
    color: "bg-[#1e3a5f]",
    demoEmail: "admin@stxaviers.edu",
    demoPassword: "admin123",
  },
  teacher: {
    title: "Teacher Login",
    subtitle: "Manage classes, attendance & marks",
    icon: BookOpen,
    color: "bg-violet-600",
    demoEmail: "teacher@stxaviers.edu",
    demoPassword: "teacher123",
  },
  student: {
    title: "Student Login",
    subtitle: "View results, attendance & assignments",
    icon: GraduationCap,
    color: "bg-emerald-600",
    demoEmail: "student@stxaviers.edu",
    demoPassword: "student123",
  },
  parent: {
    title: "Parent Login",
    subtitle: "Track your child's progress & fees",
    icon: Users,
    color: "bg-blue-600",
    demoEmail: "parent@stxaviers.edu",
    demoPassword: "parent123",
  },
};

function LoginForm() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const roleParam = (searchParams.get("role") || "parent") as keyof typeof roleConfig;
  const config = roleConfig[roleParam] || roleConfig.parent;

  const [email, setEmail] = useState(config.demoEmail);
  const [password, setPassword] = useState(config.demoPassword);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, role: roleParam }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Login failed");
        setLoading(false);
        return;
      }

      // Store session (demo uses localStorage; production should use httpOnly cookies)
      if (typeof window !== "undefined") {
        localStorage.setItem(
          "sms_session",
          JSON.stringify({
            ...data.user,
            role: data.user.role.toLowerCase(),
            loggedInAt: new Date().toISOString(),
          })
        );
      }

      const dest = data.user.role.toLowerCase();
      router.push(`/${dest}`);
    } catch (err) {
      console.error(err);
      setError("Unable to reach server. Please try again.");
      setLoading(false);
    }
  };

  const Icon = config.icon;

  return (
    <div className="min-h-screen flex">
      {/* Left panel */}
      <div className={`hidden lg:flex lg:w-1/2 ${config.color} text-white flex-col justify-between p-12 relative overflow-hidden`}>
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-64 h-64 bg-white rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-[#c9a227] rounded-full blur-3xl" />
        </div>
        <div className="relative">
          <Link href="/" className="inline-flex items-center gap-2 text-white/80 hover:text-white mb-12">
            <ArrowLeft className="w-4 h-4" />
            Back to website
          </Link>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-14 h-14 rounded-full bg-white/20 flex items-center justify-center border-2 border-[#c9a227]">
              <span className="text-xl font-bold">SX</span>
            </div>
            <div>
              <h1 className="text-xl font-bold">St. Xavier&apos;s High School</h1>
              <p className="text-sm text-white/70">School Management System</p>
            </div>
          </div>
        </div>
        <div className="relative">
          <Icon className="w-16 h-16 mb-6 opacity-90" />
          <h2 className="text-3xl font-bold mb-3 font-heading">{config.title}</h2>
          <p className="text-white/80 text-lg max-w-md">{config.subtitle}</p>
        </div>
        <p className="relative text-sm text-white/50">
          Secure role-based access • Demo environment
        </p>
      </div>

      {/* Right panel - form */}
      <div className="flex-1 flex items-center justify-center p-6 sm:p-12 bg-slate-50">
        <div className="w-full max-w-md">
          <div className="lg:hidden mb-8">
            <Link href="/" className="inline-flex items-center gap-2 text-slate-600 hover:text-[#1e3a5f] mb-6 text-sm">
              <ArrowLeft className="w-4 h-4" />
              Back to website
            </Link>
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 rounded-full ${config.color} text-white flex items-center justify-center`}>
                <Icon className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-[#1e3a5f]">{config.title}</h1>
                <p className="text-sm text-slate-500">{config.subtitle}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
            <h2 className="text-xl font-semibold text-[#1e3a5f] mb-1 hidden lg:block">
              Sign in to your account
            </h2>
            <p className="text-sm text-slate-500 mb-6 hidden lg:block">
              Enter your credentials to continue
            </p>

            {/* Role switcher */}
            <div className="flex flex-wrap gap-2 mb-6">
              {(Object.keys(roleConfig) as Array<keyof typeof roleConfig>).map((r) => (
                <Link
                  key={r}
                  href={`/login?role=${r}`}
                  className={`px-3 py-1.5 text-xs font-medium rounded-full border transition ${
                    roleParam === r
                      ? "bg-[#1e3a5f] text-white border-[#1e3a5f]"
                      : "bg-white text-slate-600 border-slate-200 hover:border-[#1e3a5f]"
                  }`}
                >
                  {r.charAt(0).toUpperCase() + r.slice(1)}
                </Link>
              ))}
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Email address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none transition text-sm"
                  placeholder="you@example.com"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none transition text-sm pr-10"
                    placeholder="••••••••"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="text-sm text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className={`w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-white font-semibold transition ${config.color} hover:opacity-90 disabled:opacity-60`}
              >
                {loading ? (
                  <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <LogIn className="w-4 h-4" />
                    Sign In
                  </>
                )}
              </button>
            </form>

            {/* Demo credentials notice */}
            <div className="mt-6 p-4 bg-amber-50 border border-amber-100 rounded-lg">
              <p className="text-xs font-semibold text-amber-800 mb-1">
                Demo Credentials (pre-filled)
              </p>
              <p className="text-xs text-amber-700">
                Email: <code className="bg-amber-100 px-1 rounded">{config.demoEmail}</code>
              </p>
              <p className="text-xs text-amber-700">
                Password: <code className="bg-amber-100 px-1 rounded">{config.demoPassword}</code>
              </p>
            </div>
          </div>

          <p className="text-center text-xs text-slate-400 mt-6">
            Protected by role-based access control. Never share your credentials.
          </p>
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center">Loading...</div>}>
      <LoginForm />
    </Suspense>
  );
}
