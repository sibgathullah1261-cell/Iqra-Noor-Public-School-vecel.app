import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { Gender, StudentStatus } from "@prisma/client";

export async function GET() {
  try {
    const students = await prisma.student.findMany({
      where: { status: "ACTIVE" },
      include: {
        section: { include: { class: true } },
        parent: true,
      },
      orderBy: [{ sectionId: "asc" }, { rollNumber: "asc" }],
      take: 200,
    });

    return NextResponse.json({
      success: true,
      count: students.length,
      students: students.map((s) => ({
        id: s.id,
        admissionNumber: s.admissionNumber,
        name: `${s.firstName} ${s.lastName}`,
        rollNumber: s.rollNumber,
        className: s.section?.class?.name ?? "—",
        sectionName: s.section?.name ?? "—",
        gender: s.gender,
        parentName: s.parent?.fatherName || s.parent?.motherName || null,
      })),
    });
  } catch (error) {
    console.error("Students API error:", error);
    return NextResponse.json({
      success: false,
      count: 0,
      students: [],
      message: "Database not ready. Run: npx prisma db push && npx tsx prisma/seed.ts",
    });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      firstName,
      lastName,
      dateOfBirth,
      gender,
      admissionNumber,
      rollNumber,
      phone,
      email,
      address,
      sectionId,
    } = body;

    if (!firstName || !lastName || !admissionNumber || !dateOfBirth) {
      return NextResponse.json(
        { error: "firstName, lastName, admissionNumber and dateOfBirth are required" },
        { status: 400 }
      );
    }

    let secId = sectionId;
    if (!secId) {
      const section = await prisma.section.findFirst({
        where: { name: "A", class: { name: "Class 10" } },
      });
      secId = section?.id;
    }

    const student = await prisma.student.create({
      data: {
        firstName,
        lastName,
        dateOfBirth: new Date(dateOfBirth),
        gender: (gender as Gender) || Gender.MALE,
        admissionNumber,
        rollNumber: rollNumber ? Number(rollNumber) : null,
        phone,
        email,
        address,
        sectionId: secId,
        status: StudentStatus.ACTIVE,
      },
    });

    return NextResponse.json({
      success: true,
      student: {
        id: student.id,
        admissionNumber: student.admissionNumber,
        name: `${student.firstName} ${student.lastName}`,
      },
    });
  } catch (error: any) {
    console.error("Create student error:", error);
    if (error?.code === "P2002") {
      return NextResponse.json({ error: "Admission number already exists" }, { status: 409 });
    }
    return NextResponse.json({
      success: false,
      error: "Could not create student. Ensure database is seeded.",
      demo: true,
    });
  }
}
