import { NextRequest, NextResponse } from "next/server";
import { feeReceiptHTML } from "@/lib/pdf";
import { generateReceiptNumber } from "@/lib/utils";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const amount = Number(searchParams.get("amount") || 8500);
  const item = searchParams.get("item") || "Tuition Fee – November 2026";

  const html = feeReceiptHTML({
    receiptNumber: generateReceiptNumber(),
    studentName: searchParams.get("name") || "Aarav Sharma",
    admissionNumber: searchParams.get("admission") || "SX2024-0842",
    className: "Class 10-A",
    items: [{ name: item, amount }],
    paymentMethod: "Online (UPI / Card)",
    transactionId: `txn_demo_${Date.now()}`,
  });

  return new NextResponse(html, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Content-Disposition": `inline; filename="fee-receipt.html"`,
    },
  });
}
