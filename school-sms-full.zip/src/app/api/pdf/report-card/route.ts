import { NextRequest, NextResponse } from "next/server";
import { reportCardHTML } from "@/lib/pdf";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const name = searchParams.get("name") || "Aarav Sharma";
  const admission = searchParams.get("admission") || "SX2024-0842";

  const html = reportCardHTML({
    studentName: name,
    admissionNumber: admission,
    className: "Class 10",
    section: "A",
    rollNumber: 15,
    examName: "Mid-Term Examination 2026",
    academicYear: "2026-2027",
    subjects: [
      { name: "Mathematics", max: 100, obtained: 88, grade: "A" },
      { name: "Physics", max: 100, obtained: 82, grade: "A" },
      { name: "Chemistry", max: 100, obtained: 91, grade: "A+" },
      { name: "English", max: 100, obtained: 85, grade: "A" },
      { name: "Hindi", max: 100, obtained: 78, grade: "B+" },
      { name: "Computer Science", max: 100, obtained: 94, grade: "A+" },
    ],
    percentage: 86.3,
    overallGrade: "A",
  });

  return new NextResponse(html, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Content-Disposition": `inline; filename="report-card-${admission}.html"`,
    },
  });
}
