import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  try {
    const userId = req.nextUrl.searchParams.get("userId");
    if (!userId) {
      return NextResponse.json({ notifications: [] });
    }

    const notifications = await prisma.notification.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      take: 30,
    });

    return NextResponse.json({ success: true, notifications });
  } catch {
    // Demo notifications when DB empty
    return NextResponse.json({
      success: true,
      notifications: [
        {
          id: "demo-1",
          title: "Welcome to St. Xavier's SMS",
          message: "Your portal is ready. Explore attendance, fees and results.",
          type: "GENERAL",
          isRead: false,
          createdAt: new Date().toISOString(),
        },
        {
          id: "demo-2",
          title: "Mid-Term results published",
          message: "You can now view and download the report card.",
          type: "RESULT",
          isRead: false,
          createdAt: new Date().toISOString(),
        },
      ],
    });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const { id, isRead } = await req.json();
    if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
    await prisma.notification.update({
      where: { id },
      data: { isRead: isRead ?? true },
    });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ success: true, demo: true });
  }
}
