import { NextRequest, NextResponse } from "next/server";
import { generateReceiptNumber } from "@/lib/utils";

/**
 * Creates a Razorpay order (sandbox / production).
 * Set RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET in .env
 *
 * Until real keys are provided, returns a demo order that the
 * frontend can complete locally.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { amount, studentId, description, feeIds } = body;

    if (!amount || amount < 1) {
      return NextResponse.json({ error: "Invalid amount" }, { status: 400 });
    }

    const amountPaise = Math.round(Number(amount) * 100); // Razorpay uses paise
    const receipt = generateReceiptNumber();

    const keyId = process.env.RAZORPAY_KEY_ID;
    const keySecret = process.env.RAZORPAY_KEY_SECRET;

    // If real keys are configured, create a live/test order
    if (keyId && keySecret && !keyId.includes("xxxx")) {
      try {
        const Razorpay = (await import("razorpay")).default;
        const rzp = new Razorpay({ key_id: keyId, key_secret: keySecret });
        const order = await rzp.orders.create({
          amount: amountPaise,
          currency: "INR",
          receipt,
          notes: {
            studentId: studentId || "",
            description: description || "School fees",
            feeIds: Array.isArray(feeIds) ? feeIds.join(",") : "",
          },
        });

        return NextResponse.json({
          success: true,
          orderId: order.id,
          amount: order.amount,
          currency: order.currency,
          keyId,
          receipt,
        });
      } catch (err) {
        console.error("Razorpay order error:", err);
        // fall through to demo
      }
    }

    // Demo / sandbox fallback
    return NextResponse.json({
      success: true,
      orderId: `order_demo_${Date.now()}`,
      amount: amountPaise,
      currency: "INR",
      keyId: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID || "rzp_test_demo",
      receipt,
      demo: true,
      message: "Demo order created. Configure RAZORPAY_KEY_ID / SECRET for real payments.",
    });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Failed to create order" }, { status: 500 });
  }
}
