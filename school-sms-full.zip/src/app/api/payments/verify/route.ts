import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { prisma } from "@/lib/prisma";
import { generateReceiptNumber } from "@/lib/utils";

/**
 * Verifies Razorpay payment signature and marks fee as paid.
 * Never trust client-side success alone.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      amount,
      studentId,
      description,
      demo,
    } = body;

    // Demo mode — accept without signature
    if (demo || String(razorpay_order_id || "").startsWith("order_demo_")) {
      const receiptNumber = generateReceiptNumber();
      // Optionally record in DB if student exists
      try {
        if (studentId) {
          await prisma.feePayment.create({
            data: {
              receiptNumber,
              studentId,
              amount: Number(amount) || 0,
              totalAmount: Number(amount) || 0,
              paymentMethod: "ONLINE",
              status: "SUCCESS",
              transactionId: razorpay_payment_id || `demo_${Date.now()}`,
              remarks: description || "Demo payment",
            },
          });
        }
      } catch {
        // DB may not be ready
      }

      return NextResponse.json({
        success: true,
        receiptNumber,
        message: "Payment recorded (demo mode)",
        demo: true,
      });
    }

    // Real signature verification
    const secret = process.env.RAZORPAY_KEY_SECRET;
    if (!secret) {
      return NextResponse.json({ error: "Payment gateway not configured" }, { status: 500 });
    }

    const payload = `${razorpay_order_id}|${razorpay_payment_id}`;
    const expected = crypto
      .createHmac("sha256", secret)
      .update(payload)
      .digest("hex");

    if (expected !== razorpay_signature) {
      return NextResponse.json({ error: "Invalid payment signature" }, { status: 400 });
    }

    const receiptNumber = generateReceiptNumber();

    if (studentId) {
      await prisma.feePayment.create({
        data: {
          receiptNumber,
          studentId,
          amount: Number(amount) || 0,
          totalAmount: Number(amount) || 0,
          paymentMethod: "ONLINE",
          status: "SUCCESS",
          transactionId: razorpay_payment_id,
          gatewayResponse: JSON.stringify({
            order_id: razorpay_order_id,
            payment_id: razorpay_payment_id,
          }),
          remarks: description,
        },
      });
    }

    return NextResponse.json({
      success: true,
      receiptNumber,
      message: "Payment verified and recorded",
    });
  } catch (error) {
    console.error("Payment verify error:", error);
    return NextResponse.json({ error: "Verification failed" }, { status: 500 });
  }
}
