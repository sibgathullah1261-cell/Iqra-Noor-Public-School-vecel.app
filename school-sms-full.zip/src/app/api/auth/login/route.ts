import { NextRequest, NextResponse } from "next/server";
import { verifyCredentials, demoLogin } from "@/lib/auth";
import { encodeSession, sessionCookieOptions } from "@/lib/session";
import { rateLimit } from "@/lib/rate-limit";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, password, role } = body;

    if (!email || !password) {
      return NextResponse.json(
        { error: "Email and password are required" },
        { status: 400 }
      );
    }

    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
    const rl = rateLimit(`login:${ip}:${email.toLowerCase()}`, 8, 60_000);
    if (!rl.ok) {
      return NextResponse.json(
        { error: "Too many login attempts. Please try again in a minute." },
        { status: 429 }
      );
    }

    let user = await verifyCredentials(email, password);
    if (!user) {
      user = demoLogin(email, password, role);
    }

    if (!user) {
      return NextResponse.json(
        { error: "Invalid email or password" },
        { status: 401 }
      );
    }

    if (role && user.role.toLowerCase() !== String(role).toLowerCase()) {
      return NextResponse.json(
        { error: `This account is a ${user.role}. Please use the correct portal.` },
        { status: 403 }
      );
    }

    const token = encodeSession({
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.name,
      studentId: user.studentId,
      teacherId: user.teacherId,
      parentId: user.parentId,
    });

    const res = NextResponse.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        name: user.name,
        studentId: user.studentId,
        teacherId: user.teacherId,
        parentId: user.parentId,
      },
    });

    const cookie = sessionCookieOptions(token);
    res.cookies.set(cookie.name, cookie.value, {
      httpOnly: cookie.httpOnly,
      secure: cookie.secure,
      sameSite: cookie.sameSite,
      path: cookie.path,
      maxAge: cookie.maxAge,
    });

    return res;
  } catch (error) {
    console.error("Login error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
