"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  BookOpen,
  ClipboardList,
  Users,
  Award,
  FileText,
  Bell,
  LogOut,
  Calendar,
  BarChart3,
} from "lucide-react";

type Session = { role: string; email: string; name: string };

export default function TeacherDashboard() {
  const router = useRouter();
  const [session, setSession] = useState<Session | null>(null);

  useEffect(() => {
    const raw = localStorage.getItem("sms_session");
    if (!raw) {
      router.replace("/login?role=teacher");
      return;
    }
    const s = JSON.parse(raw) as Session;
    if (s.role !== "teacher") {
      router.replace(`/login?role=${s.role}`);
      return;
    }
    setSession(s);
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem("sms_session");
    router.push("/login?role=teacher");
  };

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-8 h-8 border-2 border-violet-500/30 border-t-violet-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 flex">
      <aside className="w-60 bg-violet-700 text-white flex flex-col fixed h-full">
        <div className="p-5 border-b border-white/10">
          <p className="font-semibold">Teacher Portal</p>
          <p className="text-xs text-white/60">St. Xavier&apos;s High School</p>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {[
            { label: "Dashboard", href: "/teacher", icon: BarChart3, active: true },
            { label: "My Classes", href: "/teacher/classes", icon: Users },
            { label: "Attendance", href: "/teacher/attendance", icon: ClipboardList },
            { label: "Marks Entry", href: "/teacher/marks", icon: Award },
            { label: "Assignments", href: "/teacher/assignments", icon: FileText },
            { label: "Announcements", href: "/teacher/announcements", icon: Bell },
          ].map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm ${
                item.active ? "bg-white/15 font-medium" : "text-white/70 hover:bg-white/10"
              }`}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="p-3 border-t border-white/10">
          <button onClick={handleLogout} className="flex items-center gap-3 px-3 py-2.5 text-sm text-white/70 hover:text-white w-full">
            <LogOut className="w-4 h-4" /> Logout
          </button>
        </div>
      </aside>

      <main className="flex-1 ml-60">
        <header className="bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-xl font-bold text-slate-800">Good morning, {session.name}</h1>
            <p className="text-sm text-slate-500">Class Teacher • Class 10-A | Subjects: Mathematics, Physics</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-violet-600 text-white flex items-center justify-center font-semibold">
            {session.name.charAt(0)}
          </div>
        </header>

        <div className="p-6 space-y-6">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: "Assigned Classes", value: "3", icon: BookOpen },
              { label: "Students Today", value: "112", icon: Users },
              { label: "Pending Marks", value: "2 exams", icon: Award },
              { label: "Assignments Due", value: "5", icon: FileText },
            ].map((s, i) => (
              <div key={i} className="bg-white rounded-xl border p-5 shadow-sm">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm text-slate-500">{s.label}</p>
                    <p className="text-2xl font-bold mt-1">{s.value}</p>
                  </div>
                  <s.icon className="w-5 h-5 text-violet-600" />
                </div>
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl border p-5 shadow-sm">
              <h2 className="font-semibold text-slate-800 mb-4">Today&apos;s Classes</h2>
              <ul className="space-y-3">
                {[
                  { time: "08:30 – 09:15", subject: "Mathematics", class: "10-A", room: "Room 201" },
                  { time: "09:20 – 10:05", subject: "Physics", class: "10-B", room: "Lab 2" },
                  { time: "11:00 – 11:45", subject: "Mathematics", class: "10-C", room: "Room 203" },
                  { time: "12:30 – 13:15", subject: "Physics", class: "10-A", room: "Lab 2" },
                ].map((c, i) => (
                  <li key={i} className="flex items-center gap-4 p-3 rounded-lg bg-slate-50">
                    <div className="text-xs font-medium text-violet-700 w-24">{c.time}</div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">{c.subject}</p>
                      <p className="text-xs text-slate-500">{c.class} • {c.room}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-white rounded-xl border p-5 shadow-sm">
              <h2 className="font-semibold text-slate-800 mb-4">Quick Actions</h2>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: "Mark Attendance", href: "/teacher/attendance", icon: ClipboardList },
                  { label: "Enter Marks", href: "/teacher/marks", icon: Award },
                  { label: "Upload Assignment", href: "/teacher/assignments", icon: FileText },
                  { label: "View Students", href: "/teacher/classes", icon: Users },
                ].map((a, i) => (
                  <Link
                    key={i}
                    href={a.href}
                    className="flex flex-col items-center gap-2 p-4 rounded-lg border hover:border-violet-300 hover:bg-violet-50 transition"
                  >
                    <a.icon className="w-6 h-6 text-violet-600" />
                    <span className="text-xs font-medium text-center">{a.label}</span>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
