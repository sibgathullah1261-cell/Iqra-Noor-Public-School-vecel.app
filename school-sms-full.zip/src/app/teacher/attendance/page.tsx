"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  ClipboardList,
  ArrowLeft,
  Check,
  X,
  Clock,
  Save,
  LogOut,
} from "lucide-react";

type Session = { role: string; email: string; name: string };

type StudentRow = {
  id: string;
  admissionNumber: string;
  name: string;
  rollNumber: number | null;
  className: string;
  sectionName: string;
  status: "PRESENT" | "ABSENT" | "LATE" | "EXCUSED";
};

export default function TeacherAttendancePage() {
  const router = useRouter();
  const [session, setSession] = useState<Session | null>(null);
  const [students, setStudents] = useState<StudentRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [date] = useState(new Date().toISOString().slice(0, 10));

  useEffect(() => {
    const raw = localStorage.getItem("sms_session");
    if (!raw) {
      router.replace("/login?role=teacher");
      return;
    }
    const s = JSON.parse(raw) as Session;
    if (s.role !== "teacher") {
      router.replace(`/login?role=${s.role}`);
      return;
    }
    setSession(s);

    // Load students (demo + API)
    fetch("/api/students")
      .then((r) => r.json())
      .then((data) => {
        if (data.students?.length) {
          setStudents(
            data.students.map((st: any) => ({
              ...st,
              status: "PRESENT" as const,
            }))
          );
        } else {
          // Fallback demo list
          setStudents([
            { id: "1", admissionNumber: "SX2024-0842", name: "Aarav Sharma", rollNumber: 15, className: "Class 10", sectionName: "A", status: "PRESENT" },
            { id: "2", admissionNumber: "SX2024-8012", name: "Priya Patel", rollNumber: 12, className: "Class 10", sectionName: "A", status: "PRESENT" },
            { id: "3", admissionNumber: "SX2024-8018", name: "Rohan Verma", rollNumber: 18, className: "Class 10", sectionName: "A", status: "PRESENT" },
            { id: "4", admissionNumber: "SX2024-8021", name: "Sneha Iyer", rollNumber: 21, className: "Class 10", sectionName: "A", status: "PRESENT" },
            { id: "5", admissionNumber: "SX2024-8007", name: "Arjun Singh", rollNumber: 7, className: "Class 10", sectionName: "A", status: "PRESENT" },
          ]);
        }
        setLoading(false);
      })
      .catch(() => {
        setStudents([
          { id: "1", admissionNumber: "SX2024-0842", name: "Aarav Sharma", rollNumber: 15, className: "Class 10", sectionName: "A", status: "PRESENT" },
          { id: "2", admissionNumber: "SX2024-8012", name: "Priya Patel", rollNumber: 12, className: "Class 10", sectionName: "A", status: "PRESENT" },
        ]);
        setLoading(false);
      });
  }, [router]);

  const setStatus = (id: string, status: StudentRow["status"]) => {
    setStudents((prev) =>
      prev.map((s) => (s.id === id ? { ...s, status } : s))
    );
  };

  const markAllPresent = () => {
    setStudents((prev) => prev.map((s) => ({ ...s, status: "PRESENT" })));
  };

  const handleSave = async () => {
    setSaving(true);
    setMessage("");
    try {
      const res = await fetch("/api/attendance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          date,
          records: students.map((s) => ({
            studentId: s.id,
            status: s.status,
          })),
        }),
      });
      const data = await res.json();
      const present = students.filter((s) => s.status === "PRESENT" || s.status === "LATE").length;
      const absent = students.filter((s) => s.status === "ABSENT").length;
      setMessage(
        data.message ||
          `Attendance for ${date} saved (${present} present, ${absent} absent).`
      );
    } catch {
      setMessage("Could not reach server. Attendance kept locally for this session.");
    }
    setSaving(false);
  };

  const handleLogout = () => {
    localStorage.removeItem("sms_session");
    router.push("/login?role=teacher");
  };

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-8 h-8 border-2 border-violet-500/30 border-t-violet-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="bg-violet-700 text-white px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/teacher" className="p-2 hover:bg-white/10 rounded-lg">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-lg font-semibold flex items-center gap-2">
              <ClipboardList className="w-5 h-5" />
              Mark Attendance
            </h1>
            <p className="text-sm text-white/70">Class 10-A • {date}</p>
          </div>
        </div>
        <button onClick={handleLogout} className="flex items-center gap-2 text-sm text-white/80 hover:text-white">
          <LogOut className="w-4 h-4" /> Logout
        </button>
      </header>

      <main className="max-w-4xl mx-auto p-6">
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3">
            <div className="text-sm text-slate-600">
              {students.length} students • Class 10-A
            </div>
            <div className="flex gap-2">
              <button
                onClick={markAllPresent}
                className="px-3 py-1.5 text-sm border border-slate-200 rounded-lg hover:bg-slate-50"
              >
                Mark all Present
              </button>
              <button
                onClick={handleSave}
                disabled={saving}
                className="inline-flex items-center gap-2 px-4 py-1.5 text-sm font-medium text-white bg-violet-600 rounded-lg hover:bg-violet-700 disabled:opacity-60"
              >
                {saving ? (
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Save className="w-4 h-4" />
                )}
                Save Attendance
              </button>
            </div>
          </div>

          {message && (
            <div className="mx-5 mt-4 px-4 py-2.5 bg-emerald-50 border border-emerald-100 text-emerald-800 text-sm rounded-lg">
              {message}
            </div>
          )}

          {loading ? (
            <div className="p-10 text-center text-slate-500">Loading students…</div>
          ) : (
            <div className="divide-y divide-slate-50">
              {students.map((s) => (
                <div
                  key={s.id}
                  className="px-5 py-3 flex items-center gap-4 hover:bg-slate-50"
                >
                  <div className="w-10 h-10 rounded-full bg-violet-100 text-violet-700 flex items-center justify-center text-sm font-semibold flex-shrink-0">
                    {s.rollNumber ?? "—"}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-slate-800 truncate">{s.name}</p>
                    <p className="text-xs text-slate-500">{s.admissionNumber}</p>
                  </div>
                  <div className="flex gap-1.5">
                    {(
                      [
                        { key: "PRESENT", label: "P", icon: Check, color: "bg-emerald-500 text-white" },
                        { key: "ABSENT", label: "A", icon: X, color: "bg-red-500 text-white" },
                        { key: "LATE", label: "L", icon: Clock, color: "bg-amber-500 text-white" },
                        { key: "EXCUSED", label: "E", icon: Check, color: "bg-blue-500 text-white" },
                      ] as const
                    ).map((opt) => (
                      <button
                        key={opt.key}
                        onClick={() => setStatus(s.id, opt.key)}
                        className={`w-9 h-9 rounded-lg flex items-center justify-center text-xs font-bold transition ${
                          s.status === opt.key
                            ? opt.color
                            : "bg-slate-100 text-slate-500 hover:bg-slate-200"
                        }`}
                        title={opt.key}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <p className="text-xs text-slate-400 mt-4 text-center">
          Demo mode: attendance is simulated. After seeding the database, this will persist to the StudentAttendance table.
        </p>
      </main>
    </div>
  );
}
