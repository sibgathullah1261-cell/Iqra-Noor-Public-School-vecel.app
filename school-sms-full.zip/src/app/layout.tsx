import type { Metadata } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-heading",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "St. Xavier's High School | Excellence in Education",
    template: "%s | St. Xavier's High School",
  },
  description:
    "Official website and School Management System of St. Xavier's High School. Empowering students since 1985 with quality education, holistic development, and modern facilities.",
  keywords: [
    "school",
    "education",
    "St. Xavier's",
    "admission",
    "school management",
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${playfair.variable}`}>
      <body className="min-h-screen antialiased font-sans bg-white text-slate-900">
        {children}
      </body>
    </html>
  );
}
