"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  CreditCard,
  ArrowLeft,
  LogOut,
  CheckCircle,
  Download,
} from "lucide-react";

type Session = { role: string; email: string; name: string };

const feeItems = [
  { id: "1", name: "Tuition Fee – November 2026", amount: 8500, status: "PAID", due: "10 Nov 2026" },
  { id: "2", name: "Transport Fee – November 2026", amount: 2000, status: "PAID", due: "10 Nov 2026" },
  { id: "3", name: "Tuition Fee – December 2026", amount: 8500, status: "PENDING", due: "10 Dec 2026" },
  { id: "4", name: "Transport Fee – December 2026", amount: 2000, status: "PENDING", due: "10 Dec 2026" },
  { id: "5", name: "Examination Fee – Mid Term", amount: 500, status: "PAID", due: "01 Oct 2026" },
];

export default function ParentFeesPage() {
  const router = useRouter();
  const [session, setSession] = useState<Session | null>(null);
  const [items, setItems] = useState(feeItems);
  const [paying, setPaying] = useState<string | null>(null);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const raw = localStorage.getItem("sms_session");
    if (!raw) {
      router.replace("/login?role=parent");
      return;
    }
    const s = JSON.parse(raw) as Session;
    if (s.role !== "parent") {
      router.replace(`/login?role=${s.role}`);
      return;
    }
    setSession(s);
  }, [router]);

  const totalPending = items
    .filter((i) => i.status === "PENDING")
    .reduce((sum, i) => sum + i.amount, 0);

  const processPayment = async (amount: number, description: string, ids: string[]) => {
    // 1. Create order
    const orderRes = await fetch("/api/payments/create-order", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amount, description, feeIds: ids }),
    });
    const order = await orderRes.json();
    if (!order.success) throw new Error(order.error || "Order failed");

    // 2. In production: open Razorpay checkout here with order.orderId
    // For demo we immediately verify
    const verifyRes = await fetch("/api/payments/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        razorpay_order_id: order.orderId,
        razorpay_payment_id: `pay_demo_${Date.now()}`,
        amount,
        description,
        demo: true,
      }),
    });
    const verify = await verifyRes.json();
    return verify;
  };

  const handlePay = async (id: string) => {
    setPaying(id);
    setMessage("");
    try {
      const item = items.find((i) => i.id === id)!;
      const result = await processPayment(item.amount, item.name, [id]);
      setItems((prev) => prev.map((i) => (i.id === id ? { ...i, status: "PAID" } : i)));
      setMessage(
        result.message +
          (result.receiptNumber ? ` Receipt: ${result.receiptNumber}` : "")
      );
    } catch (e: any) {
      setMessage(e.message || "Payment failed");
    }
    setPaying(null);
  };

  const handlePayAll = async () => {
    setPaying("all");
    setMessage("");
    try {
      const pending = items.filter((i) => i.status === "PENDING");
      const amount = pending.reduce((s, i) => s + i.amount, 0);
      const result = await processPayment(amount, "All pending fees", pending.map((i) => i.id));
      setItems((prev) => prev.map((i) => ({ ...i, status: "PAID" })));
      setMessage(result.message + (result.receiptNumber ? ` Receipt: ${result.receiptNumber}` : ""));
    } catch (e: any) {
      setMessage(e.message || "Payment failed");
    }
    setPaying(null);
  };

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="bg-blue-700 text-white px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/parent" className="p-2 hover:bg-white/10 rounded-lg">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-lg font-semibold flex items-center gap-2">
              <CreditCard className="w-5 h-5" />
              Fees & Payments
            </h1>
            <p className="text-sm text-white/70">Aarav Sharma • Class 10-A</p>
          </div>
        </div>
        <button
          onClick={() => {
            localStorage.removeItem("sms_session");
            router.push("/login?role=parent");
          }}
          className="flex items-center gap-2 text-sm text-white/80 hover:text-white"
        >
          <LogOut className="w-4 h-4" /> Logout
        </button>
      </header>

      <main className="max-w-3xl mx-auto p-6 space-y-6">
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-sm text-slate-500">Total Pending</p>
            <p className="text-2xl font-bold text-slate-900">
              ₹{totalPending.toLocaleString("en-IN")}
            </p>
          </div>
          {totalPending > 0 && (
            <button
              onClick={handlePayAll}
              disabled={!!paying}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#c9a227] text-[#1e3a5f] rounded-lg text-sm font-semibold hover:bg-[#d4b02e] disabled:opacity-60"
            >
              {paying === "all" ? (
                <span className="w-4 h-4 border-2 border-[#1e3a5f]/30 border-t-[#1e3a5f] rounded-full animate-spin" />
              ) : (
                <CreditCard className="w-4 h-4" />
              )}
              Pay All Pending
            </button>
          )}
        </div>

        {message && (
          <div className="flex items-start gap-3 px-4 py-3 bg-emerald-50 border border-emerald-100 text-emerald-800 text-sm rounded-lg">
            <CheckCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            {message}
          </div>
        )}

        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-5 py-3 border-b border-slate-100 font-medium text-slate-800">
            Fee Statement
          </div>
          <div className="divide-y divide-slate-50">
            {items.map((item) => (
              <div
                key={item.id}
                className="px-5 py-4 flex flex-wrap items-center gap-3"
              >
                <div className="flex-1 min-w-[160px]">
                  <p className="font-medium text-slate-800 text-sm">{item.name}</p>
                  <p className="text-xs text-slate-500">Due: {item.due}</p>
                </div>
                <p className="font-semibold text-slate-900">
                  ₹{item.amount.toLocaleString("en-IN")}
                </p>
                {item.status === "PAID" ? (
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 text-xs font-medium bg-emerald-50 text-emerald-700 rounded-full">
                      Paid
                    </span>
                    <a
                      href={`/api/pdf/fee-receipt?amount=${item.amount}&item=${encodeURIComponent(item.name)}&name=Aarav%20Sharma`}
                      target="_blank"
                      rel="noreferrer"
                      className="p-1.5 text-slate-400 hover:text-blue-600"
                      title="Download receipt"
                    >
                      <Download className="w-4 h-4" />
                    </a>
                  </div>
                ) : (
                  <button
                    onClick={() => handlePay(item.id)}
                    disabled={!!paying}
                    className="px-3 py-1.5 text-xs font-medium bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-60"
                  >
                    {paying === item.id ? "Processing…" : "Pay Now"}
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        <p className="text-xs text-slate-400 text-center">
          Demo mode: payments are simulated. Production uses Razorpay with server-side signature verification. Card/UPI details are never stored on the school server.
        </p>
      </main>
    </div>
  );
}
