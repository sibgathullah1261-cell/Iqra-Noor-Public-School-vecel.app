"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  Users,
  ClipboardList,
  Award,
  CreditCard,
  Bell,
  LogOut,
  Calendar,
  FileText,
  MessageSquare,
  Download,
} from "lucide-react";

type Session = { role: string; email: string; name: string };

export default function ParentDashboard() {
  const router = useRouter();
  const [session, setSession] = useState<Session | null>(null);

  useEffect(() => {
    const raw = localStorage.getItem("sms_session");
    if (!raw) {
      router.replace("/login?role=parent");
      return;
    }
    const s = JSON.parse(raw) as Session;
    if (s.role !== "parent") {
      router.replace(`/login?role=${s.role}`);
      return;
    }
    setSession(s);
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem("sms_session");
    router.push("/login?role=parent");
  };

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-8 h-8 border-2 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 flex">
      <aside className="w-60 bg-blue-700 text-white flex flex-col fixed h-full">
        <div className="p-5 border-b border-white/10">
          <p className="font-semibold">Parent Portal</p>
          <p className="text-xs text-white/60">St. Xavier&apos;s High School</p>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {[
            { label: "Dashboard", href: "/parent", icon: Users, active: true },
            { label: "Attendance", href: "/parent/attendance", icon: ClipboardList },
            { label: "Results", href: "/parent/results", icon: Award },
            { label: "Fees & Payments", href: "/parent/fees", icon: CreditCard },
            { label: "Assignments", href: "/parent/assignments", icon: FileText },
            { label: "Notices", href: "/parent/notices", icon: Bell },
            { label: "Leave Application", href: "/parent/leave", icon: Calendar },
            { label: "Contact School", href: "/parent/contact", icon: MessageSquare },
          ].map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm ${
                item.active ? "bg-white/15 font-medium" : "text-white/70 hover:bg-white/10"
              }`}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="p-3 border-t border-white/10">
          <button onClick={handleLogout} className="flex items-center gap-3 px-3 py-2.5 text-sm text-white/70 hover:text-white w-full">
            <LogOut className="w-4 h-4" /> Logout
          </button>
        </div>
      </aside>

      <main className="flex-1 ml-60">
        <header className="bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-xl font-bold text-slate-800">Welcome, {session.name}</h1>
            <p className="text-sm text-slate-500">Linked student: Aarav Sharma (Class 10-A)</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-semibold">
            {session.name.charAt(0)}
          </div>
        </header>

        <div className="p-6 space-y-6">
          {/* Child card */}
          <div className="bg-white rounded-xl border p-5 shadow-sm flex flex-col sm:flex-row gap-5 items-start sm:items-center">
            <div className="w-16 h-16 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xl font-bold">
              AS
            </div>
            <div className="flex-1">
              <h2 className="text-lg font-semibold text-slate-800">Aarav Sharma</h2>
              <p className="text-sm text-slate-500">
                Admission No: SX2024-0842 • Class 10-A • Roll No: 15 • Academic Year 2026-27
              </p>
            </div>
            <div className="flex gap-2">
              <span className="px-3 py-1 bg-emerald-50 text-emerald-700 text-xs font-medium rounded-full">
                Attendance 94.2%
              </span>
              <span className="px-3 py-1 bg-blue-50 text-blue-700 text-xs font-medium rounded-full">
                Fees Clear
              </span>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: "Today's Status", value: "Present", sub: "Marked at 08:12", color: "text-emerald-600" },
              { label: "This Month Attendance", value: "94.2%", sub: "19/20 days", color: "text-blue-600" },
              { label: "Last Exam Average", value: "87.5%", sub: "Mid-Term", color: "text-violet-600" },
              { label: "Pending Fees", value: "₹0", sub: "Next due: Dec 2026", color: "text-emerald-600" },
            ].map((s, i) => (
              <div key={i} className="bg-white rounded-xl border p-5 shadow-sm">
                <p className="text-sm text-slate-500">{s.label}</p>
                <p className={`text-2xl font-bold mt-1 ${s.color}`}>{s.value}</p>
                <p className="text-xs text-slate-400 mt-1">{s.sub}</p>
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl border p-5 shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h2 className="font-semibold text-slate-800">Fee Summary</h2>
                <Link href="/parent/fees" className="text-sm text-blue-600 hover:underline">
                  Pay / History
                </Link>
              </div>
              <div className="space-y-3">
                {[
                  { name: "Tuition Fee – Nov 2026", amount: "₹8,500", status: "Paid" },
                  { name: "Transport Fee – Nov 2026", amount: "₹2,000", status: "Paid" },
                  { name: "Tuition Fee – Dec 2026", amount: "₹8,500", status: "Upcoming" },
                ].map((f, i) => (
                  <div key={i} className="flex justify-between items-center py-2 border-b border-slate-50 last:border-0">
                    <div>
                      <p className="text-sm font-medium">{f.name}</p>
                      <p className="text-xs text-slate-500">{f.amount}</p>
                    </div>
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                        f.status === "Paid"
                          ? "bg-emerald-50 text-emerald-700"
                          : "bg-amber-50 text-amber-700"
                      }`}
                    >
                      {f.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-xl border p-5 shadow-sm">
              <h2 className="font-semibold text-slate-800 mb-4">Notifications</h2>
              <ul className="space-y-3">
                {[
                  { text: "Aarav was present today", time: "Today, 08:15", type: "attendance" },
                  { text: "Mid-Term report card available for download", time: "Yesterday", type: "result" },
                  { text: "Fee receipt for November generated", time: "2 days ago", type: "fee" },
                  { text: "Parent-Teacher Meeting on 22 Nov", time: "3 days ago", type: "event" },
                ].map((n, i) => (
                  <li key={i} className="flex gap-3">
                    <div className="w-2 h-2 rounded-full bg-blue-500 mt-1.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-slate-700">{n.text}</p>
                      <p className="text-xs text-slate-400">{n.time}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-white rounded-xl border p-5 shadow-sm">
            <h2 className="font-semibold text-slate-800 mb-3">Quick Downloads</h2>
            <div className="flex flex-wrap gap-3">
              {[
                "Report Card (Mid-Term)",
                "Fee Receipt – Nov",
                "Attendance Report",
                "Bonafide Certificate",
              ].map((doc, i) => (
                <button
                  key={i}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm border border-slate-200 rounded-lg hover:border-blue-300 hover:bg-blue-50 transition"
                >
                  <Download className="w-4 h-4 text-blue-600" />
                  {doc}
                </button>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
