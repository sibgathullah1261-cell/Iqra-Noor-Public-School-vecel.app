"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Award, ArrowLeft, LogOut, Plus } from "lucide-react";

type Session = { role: string; email: string; name: string };

const demoExams = [
  { id: "1", name: "Mid-Term Examination 2026", type: "MID_TERM", start: "2026-09-15", end: "2026-09-25", published: true, classes: "9, 10" },
  { id: "2", name: "Unit Test 2", type: "UNIT_TEST", start: "2026-11-10", end: "2026-11-14", published: false, classes: "6–10" },
  { id: "3", name: "Final Examination 2027", type: "FINAL", start: "2027-02-20", end: "2027-03-10", published: false, classes: "All" },
];

export default function AdminExamsPage() {
  const router = useRouter();
  const [session, setSession] = useState<Session | null>(null);
  const [exams, setExams] = useState(demoExams);

  useEffect(() => {
    const raw = localStorage.getItem("sms_session");
    if (!raw) {
      router.replace("/login?role=admin");
      return;
    }
    const s = JSON.parse(raw) as Session;
    if (s.role !== "admin") {
      router.replace(`/login?role=${s.role}`);
      return;
    }
    setSession(s);
  }, [router]);

  const togglePublish = (id: string) => {
    setExams((prev) =>
      prev.map((e) => (e.id === id ? { ...e, published: !e.published } : e))
    );
  };

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-8 h-8 border-2 border-[#1e3a5f]/30 border-t-[#1e3a5f] rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="bg-[#1e3a5f] text-white px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/admin" className="p-2 hover:bg-white/10 rounded-lg">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-lg font-semibold flex items-center gap-2">
              <Award className="w-5 h-5" />
              Examination Management
            </h1>
            <p className="text-sm text-white/70">Create, publish and manage results</p>
          </div>
        </div>
        <button
          onClick={() => {
            localStorage.removeItem("sms_session");
            router.push("/login?role=admin");
          }}
          className="flex items-center gap-2 text-sm text-white/80 hover:text-white"
        >
          <LogOut className="w-4 h-4" /> Logout
        </button>
      </header>

      <main className="max-w-4xl mx-auto p-6 space-y-6">
        <div className="flex justify-end">
          <button className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#c9a227] text-[#1e3a5f] rounded-lg text-sm font-semibold">
            <Plus className="w-4 h-4" /> New Examination
          </button>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="divide-y divide-slate-50">
            {exams.map((exam) => (
              <div key={exam.id} className="px-5 py-4 flex flex-wrap items-center gap-4">
                <div className="flex-1 min-w-[200px]">
                  <p className="font-medium text-slate-800">{exam.name}</p>
                  <p className="text-xs text-slate-500">
                    {exam.type.replace("_", " ")} · {exam.start} → {exam.end} · Classes: {exam.classes}
                  </p>
                </div>
                <span
                  className={`px-2.5 py-1 text-xs font-medium rounded-full ${
                    exam.published
                      ? "bg-emerald-50 text-emerald-700"
                      : "bg-slate-100 text-slate-600"
                  }`}
                >
                  {exam.published ? "Published" : "Draft"}
                </span>
                <button
                  onClick={() => togglePublish(exam.id)}
                  className="px-3 py-1.5 text-xs font-medium border border-slate-200 rounded-lg hover:bg-slate-50"
                >
                  {exam.published ? "Unpublish" : "Publish Results"}
                </button>
                <a
                  href="/api/pdf/report-card"
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 text-xs font-medium text-[#1e3a5f] hover:underline"
                >
                  Sample Report Card
                </a>
              </div>
            ))}
          </div>
        </div>

        <p className="text-xs text-slate-400 text-center">
          Full mark entry is done by teachers under their portal. Admin publishes results so students and parents can view them.
        </p>
      </main>
    </div>
  );
}
