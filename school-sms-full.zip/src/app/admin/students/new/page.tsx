"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, UserPlus, LogOut } from "lucide-react";

type Session = { role: string; email: string; name: string };

export default function NewStudentPage() {
  const router = useRouter();
  const [session, setSession] = useState<Session | null>(null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    dateOfBirth: "",
    gender: "MALE",
    admissionNumber: "",
    rollNumber: "",
    phone: "",
    email: "",
    address: "",
  });

  useEffect(() => {
    const raw = localStorage.getItem("sms_session");
    if (!raw) {
      router.replace("/login?role=admin");
      return;
    }
    const s = JSON.parse(raw) as Session;
    if (s.role !== "admin") {
      router.replace(`/login?role=${s.role}`);
      return;
    }
    setSession(s);
    // Auto admission number suggestion
    setForm((f) => ({
      ...f,
      admissionNumber: `SX${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9000) + 1000)}`,
    }));
  }, [router]);

  const update = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage("");
    try {
      const res = await fetch("/api/students", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          rollNumber: form.rollNumber ? Number(form.rollNumber) : null,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setMessage(`Student ${form.firstName} ${form.lastName} created successfully.`);
        setTimeout(() => router.push("/admin/students"), 1200);
      } else {
        setMessage(data.error || data.message || "Could not create student (demo mode may still succeed on seed).");
      }
    } catch {
      setMessage("Server unreachable. Student form data retained.");
    }
    setSaving(false);
  };

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-8 h-8 border-2 border-[#1e3a5f]/30 border-t-[#1e3a5f] rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="bg-[#1e3a5f] text-white px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/admin/students" className="p-2 hover:bg-white/10 rounded-lg">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <h1 className="text-lg font-semibold flex items-center gap-2">
            <UserPlus className="w-5 h-5" /> Add New Student
          </h1>
        </div>
        <button
          onClick={() => {
            localStorage.removeItem("sms_session");
            router.push("/login?role=admin");
          }}
          className="flex items-center gap-2 text-sm text-white/80 hover:text-white"
        >
          <LogOut className="w-4 h-4" /> Logout
        </button>
      </header>

      <main className="max-w-2xl mx-auto p-6">
        <form onSubmit={handleSubmit} className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
          {message && (
            <div className="px-4 py-2.5 bg-emerald-50 border border-emerald-100 text-emerald-800 text-sm rounded-lg">
              {message}
            </div>
          )}
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">First Name *</label>
              <input required value={form.firstName} onChange={(e) => update("firstName", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-[#1e3a5f]" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Last Name *</label>
              <input required value={form.lastName} onChange={(e) => update("lastName", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-[#1e3a5f]" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Admission Number *</label>
              <input required value={form.admissionNumber} onChange={(e) => update("admissionNumber", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-[#1e3a5f] font-mono" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Roll Number</label>
              <input type="number" value={form.rollNumber} onChange={(e) => update("rollNumber", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-[#1e3a5f]" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Date of Birth *</label>
              <input type="date" required value={form.dateOfBirth} onChange={(e) => update("dateOfBirth", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-[#1e3a5f]" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Gender</label>
              <select value={form.gender} onChange={(e) => update("gender", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-[#1e3a5f]">
                <option value="MALE">Male</option>
                <option value="FEMALE">Female</option>
                <option value="OTHER">Other</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Phone</label>
              <input value={form.phone} onChange={(e) => update("phone", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-[#1e3a5f]" />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
              <input type="email" value={form.email} onChange={(e) => update("email", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-[#1e3a5f]" />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-1">Address</label>
              <textarea rows={2} value={form.address} onChange={(e) => update("address", e.target.value)} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm outline-none focus:border-[#1e3a5f]" />
            </div>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Link href="/admin/students" className="px-4 py-2 border border-slate-300 rounded-lg text-sm hover:bg-slate-50">
              Cancel
            </Link>
            <button type="submit" disabled={saving} className="inline-flex items-center gap-2 px-5 py-2 bg-[#1e3a5f] text-white rounded-lg text-sm font-medium hover:bg-[#2a4a6f] disabled:opacity-60">
              {saving ? <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <UserPlus className="w-4 h-4" />}
              Create Student
            </button>
          </div>
        </form>
      </main>
    </div>
  );
}
