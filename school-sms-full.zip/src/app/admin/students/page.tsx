"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  Users,
  ArrowLeft,
  Search,
  Plus,
  LogOut,
} from "lucide-react";

type Session = { role: string; email: string; name: string };
type Student = {
  id: string;
  admissionNumber: string;
  name: string;
  rollNumber: number | null;
  className: string;
  sectionName: string;
  gender: string;
  parentName: string | null;
};

export default function AdminStudentsPage() {
  const router = useRouter();
  const [session, setSession] = useState<Session | null>(null);
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    const raw = localStorage.getItem("sms_session");
    if (!raw) {
      router.replace("/login?role=admin");
      return;
    }
    const s = JSON.parse(raw) as Session;
    if (s.role !== "admin") {
      router.replace(`/login?role=${s.role}`);
      return;
    }
    setSession(s);

    fetch("/api/students")
      .then((r) => r.json())
      .then((data) => {
        setStudents(data.students || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [router]);

  const filtered = students.filter(
    (s) =>
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.admissionNumber.toLowerCase().includes(search.toLowerCase())
  );

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-8 h-8 border-2 border-[#1e3a5f]/30 border-t-[#1e3a5f] rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="bg-[#1e3a5f] text-white px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/admin" className="p-2 hover:bg-white/10 rounded-lg">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-lg font-semibold flex items-center gap-2">
              <Users className="w-5 h-5" />
              Student Management
            </h1>
            <p className="text-sm text-white/70">{students.length} students</p>
          </div>
        </div>
        <button
          onClick={() => {
            localStorage.removeItem("sms_session");
            router.push("/login?role=admin");
          }}
          className="flex items-center gap-2 text-sm text-white/80 hover:text-white"
        >
          <LogOut className="w-4 h-4" /> Logout
        </button>
      </header>

      <main className="max-w-6xl mx-auto p-6">
        <div className="flex flex-wrap gap-3 mb-6">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name or admission number..."
              className="w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-lg text-sm bg-white focus:ring-2 focus:ring-[#1e3a5f]/20 focus:border-[#1e3a5f] outline-none"
            />
          </div>
          <Link href="/admin/students/new" className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#c9a227] text-[#1e3a5f] rounded-lg text-sm font-semibold hover:bg-[#d4b02e]">
            <Plus className="w-4 h-4" />
            Add Student
          </Link>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          {loading ? (
            <div className="p-10 text-center text-slate-500">Loading students…</div>
          ) : filtered.length === 0 ? (
            <div className="p-10 text-center text-slate-500">
              {students.length === 0
                ? "No students found. Run the seed script: npx tsx prisma/seed.ts"
                : "No matching students"}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-slate-500 border-b border-slate-100 bg-slate-50">
                    <th className="px-5 py-3 font-medium">Admission No.</th>
                    <th className="px-5 py-3 font-medium">Name</th>
                    <th className="px-5 py-3 font-medium">Class</th>
                    <th className="px-5 py-3 font-medium">Roll</th>
                    <th className="px-5 py-3 font-medium">Gender</th>
                    <th className="px-5 py-3 font-medium">Parent</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {filtered.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50">
                      <td className="px-5 py-3 font-mono text-xs">{s.admissionNumber}</td>
                      <td className="px-5 py-3 font-medium text-slate-800">{s.name}</td>
                      <td className="px-5 py-3">
                        {s.className}-{s.sectionName}
                      </td>
                      <td className="px-5 py-3">{s.rollNumber ?? "—"}</td>
                      <td className="px-5 py-3 capitalize">{s.gender?.toLowerCase()}</td>
                      <td className="px-5 py-3 text-slate-600">{s.parentName || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
