"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { FileText, ArrowLeft, LogOut, Check, X } from "lucide-react";

type Session = { role: string; email: string; name: string };
type Application = {
  id: string;
  applicationNumber: string;
  studentFirstName: string;
  studentLastName: string;
  applyingClass: string;
  phone: string;
  status: string;
  createdAt: string;
};

export default function AdminAdmissionsPage() {
  const router = useRouter();
  const [session, setSession] = useState<Session | null>(null);
  const [apps, setApps] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const raw = localStorage.getItem("sms_session");
    if (!raw) {
      router.replace("/login?role=admin");
      return;
    }
    const s = JSON.parse(raw) as Session;
    if (s.role !== "admin") {
      router.replace(`/login?role=${s.role}`);
      return;
    }
    setSession(s);

    fetch("/api/admissions")
      .then((r) => r.json())
      .then((data) => {
        setApps(data.applications || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [router]);

  const updateStatus = async (id: string, status: string) => {
    try {
      await fetch("/api/admissions", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status }),
      });
      setApps((prev) =>
        prev.map((a) => (a.id === id ? { ...a, status } : a))
      );
    } catch {
      // demo: still update UI
      setApps((prev) =>
        prev.map((a) => (a.id === id ? { ...a, status } : a))
      );
    }
  };

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-8 h-8 border-2 border-[#1e3a5f]/30 border-t-[#1e3a5f] rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="bg-[#1e3a5f] text-white px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/admin" className="p-2 hover:bg-white/10 rounded-lg">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-lg font-semibold flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Admission Applications
            </h1>
            <p className="text-sm text-white/70">{apps.length} applications</p>
          </div>
        </div>
        <button
          onClick={() => {
            localStorage.removeItem("sms_session");
            router.push("/login?role=admin");
          }}
          className="flex items-center gap-2 text-sm text-white/80 hover:text-white"
        >
          <LogOut className="w-4 h-4" /> Logout
        </button>
      </header>

      <main className="max-w-5xl mx-auto p-6">
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          {loading ? (
            <div className="p-10 text-center text-slate-500">Loading…</div>
          ) : apps.length === 0 ? (
            <div className="p-10 text-center text-slate-500">
              No applications yet. Submit one from the{" "}
              <Link href="/admissions" className="text-[#1e3a5f] underline">
                Online Admission
              </Link>{" "}
              page.
            </div>
          ) : (
            <div className="divide-y divide-slate-50">
              {apps.map((a) => (
                <div
                  key={a.id}
                  className="px-5 py-4 flex flex-wrap items-center gap-4 hover:bg-slate-50"
                >
                  <div className="flex-1 min-w-[180px]">
                    <p className="font-medium text-slate-800">
                      {a.studentFirstName} {a.studentLastName}
                    </p>
                    <p className="text-xs text-slate-500">
                      {a.applicationNumber} • Applying: {a.applyingClass} • {a.phone}
                    </p>
                  </div>
                  <span
                    className={`px-2.5 py-1 text-xs font-medium rounded-full ${
                      a.status === "APPROVED"
                        ? "bg-emerald-50 text-emerald-700"
                        : a.status === "REJECTED"
                        ? "bg-red-50 text-red-700"
                        : "bg-amber-50 text-amber-700"
                    }`}
                  >
                    {a.status}
                  </span>
                  {a.status === "PENDING" && (
                    <div className="flex gap-2">
                      <button
                        onClick={() => updateStatus(a.id, "APPROVED")}
                        className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium bg-emerald-600 text-white rounded-lg hover:bg-emerald-700"
                      >
                        <Check className="w-3.5 h-3.5" /> Approve
                      </button>
                      <button
                        onClick={() => updateStatus(a.id, "REJECTED")}
                        className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium bg-red-600 text-white rounded-lg hover:bg-red-700"
                      >
                        <X className="w-3.5 h-3.5" /> Reject
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
