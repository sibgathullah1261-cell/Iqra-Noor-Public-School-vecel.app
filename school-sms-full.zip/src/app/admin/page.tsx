"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  Users,
  GraduationCap,
  BookOpen,
  CreditCard,
  ClipboardList,
  Bell,
  FileText,
  Settings,
  LogOut,
  TrendingUp,
  UserPlus,
  Calendar,
  Award,
  BarChart3,
  School,
} from "lucide-react";

type Session = {
  role: string;
  email: string;
  name: string;
};

const stats = [
  { label: "Total Students", value: "2,418", icon: Users, change: "+42 this month", color: "bg-blue-500" },
  { label: "Total Teachers", value: "128", icon: GraduationCap, change: "+3 this month", color: "bg-violet-500" },
  { label: "Parents Registered", value: "1,956", icon: Users, change: "+28 this month", color: "bg-emerald-500" },
  { label: "Pending Fees", value: "₹4.2L", icon: CreditCard, change: "87 students", color: "bg-amber-500" },
];

const quickActions = [
  { label: "Add Student", href: "/admin/students/new", icon: UserPlus },
  { label: "Mark Attendance", href: "/admin/attendance", icon: ClipboardList },
  { label: "Fee Collection", href: "/admin/fees", icon: CreditCard },
  { label: "Publish Results", href: "/admin/exams", icon: Award },
  { label: "New Announcement", href: "/admin/announcements", icon: Bell },
  { label: "Admission Requests", href: "/admin/admissions", icon: FileText },
];

const recentActivity = [
  { text: "New admission application #ADM20260142 received", time: "12 min ago" },
  { text: "Fee payment of ₹12,500 received from Aarav Sharma", time: "45 min ago" },
  { text: "Mrs. Anjali Mehta marked Class 10-A attendance", time: "1 hour ago" },
  { text: "Mid-Term results published for Class 9", time: "2 hours ago" },
  { text: "Leave application approved for Priya Patel (Class 8-B)", time: "3 hours ago" },
];

export default function AdminDashboard() {
  const router = useRouter();
  const [session, setSession] = useState<Session | null>(null);

  useEffect(() => {
    const raw = localStorage.getItem("sms_session");
    if (!raw) {
      router.replace("/login?role=admin");
      return;
    }
    const s = JSON.parse(raw) as Session;
    if (s.role !== "admin") {
      router.replace(`/login?role=${s.role}`);
      return;
    }
    setSession(s);
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem("sms_session");
    router.push("/login?role=admin");
  };

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="w-8 h-8 border-2 border-[#1e3a5f]/30 border-t-[#1e3a5f] rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-[#1e3a5f] text-white flex flex-col fixed h-full z-20">
        <div className="p-5 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-full bg-[#c9a227] text-[#1e3a5f] flex items-center justify-center font-bold text-sm">
              SX
            </div>
            <div>
              <p className="font-semibold text-sm leading-tight">St. Xavier&apos;s</p>
              <p className="text-xs text-white/60">Admin Panel</p>
            </div>
          </div>
        </div>
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {[
            { label: "Dashboard", href: "/admin", icon: BarChart3, active: true },
            { label: "Students", href: "/admin/students", icon: Users },
            { label: "Teachers", href: "/admin/teachers", icon: GraduationCap },
            { label: "Parents", href: "/admin/parents", icon: Users },
            { label: "Classes & Subjects", href: "/admin/classes", icon: School },
            { label: "Attendance", href: "/admin/attendance", icon: ClipboardList },
            { label: "Fees", href: "/admin/fees", icon: CreditCard },
            { label: "Examinations", href: "/admin/exams", icon: Award },
            { label: "Admissions", href: "/admin/admissions", icon: FileText },
            { label: "Announcements", href: "/admin/announcements", icon: Bell },
            { label: "Reports", href: "/admin/reports", icon: TrendingUp },
            { label: "Settings", href: "/admin/settings", icon: Settings },
          ].map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition ${
                item.active
                  ? "bg-white/15 text-white font-medium"
                  : "text-white/70 hover:bg-white/10 hover:text-white"
              }`}
            >
              <item.icon className="w-4.5 h-4.5" />
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="p-3 border-t border-white/10">
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-white/70 hover:bg-white/10 hover:text-white w-full transition"
          >
            <LogOut className="w-4.5 h-4.5" />
            Logout
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 ml-64">
        {/* Top bar */}
        <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
          <div className="px-6 py-4 flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-[#1e3a5f]">Dashboard</h1>
              <p className="text-sm text-slate-500">
                Welcome back, {session.name}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button className="relative p-2 rounded-lg hover:bg-slate-100 text-slate-600">
                <Bell className="w-5 h-5" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
              </button>
              <div className="flex items-center gap-2 pl-3 border-l border-slate-200">
                <div className="w-9 h-9 rounded-full bg-[#1e3a5f] text-white flex items-center justify-center text-sm font-semibold">
                  {session.name.charAt(0)}
                </div>
                <div className="hidden sm:block">
                  <p className="text-sm font-medium text-slate-800">{session.name}</p>
                  <p className="text-xs text-slate-500">Administrator</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        <div className="p-6 space-y-6">
          {/* Stats */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {stats.map((s, i) => (
              <div
                key={i}
                className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-slate-500 mb-1">{s.label}</p>
                    <p className="text-2xl font-bold text-slate-900">{s.value}</p>
                    <p className="text-xs text-slate-400 mt-1">{s.change}</p>
                  </div>
                  <div className={`w-10 h-10 rounded-lg ${s.color} text-white flex items-center justify-center`}>
                    <s.icon className="w-5 h-5" />
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Quick Actions */}
            <div className="lg:col-span-1 bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
              <h2 className="font-semibold text-[#1e3a5f] mb-4">Quick Actions</h2>
              <div className="grid grid-cols-2 gap-3">
                {quickActions.map((a, i) => (
                  <Link
                    key={i}
                    href={a.href}
                    className="flex flex-col items-center gap-2 p-3 rounded-lg border border-slate-100 hover:border-[#c9a227] hover:bg-amber-50/50 transition text-center"
                  >
                    <a.icon className="w-5 h-5 text-[#1e3a5f]" />
                    <span className="text-xs font-medium text-slate-700">{a.label}</span>
                  </Link>
                ))}
              </div>
            </div>

            {/* Recent Activity */}
            <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
              <h2 className="font-semibold text-[#1e3a5f] mb-4">Recent Activity</h2>
              <ul className="space-y-3">
                {recentActivity.map((item, i) => (
                  <li key={i} className="flex gap-3 text-sm">
                    <div className="w-2 h-2 rounded-full bg-[#c9a227] mt-1.5 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-slate-700">{item.text}</p>
                      <p className="text-xs text-slate-400 mt-0.5">{item.time}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Class-wise snapshot */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-[#1e3a5f]">Class-wise Student Strength</h2>
              <Link href="/admin/students" className="text-sm text-[#1e3a5f] hover:underline">
                View all
              </Link>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-slate-500 border-b border-slate-100">
                    <th className="pb-3 font-medium">Class</th>
                    <th className="pb-3 font-medium">Sections</th>
                    <th className="pb-3 font-medium">Students</th>
                    <th className="pb-3 font-medium">Attendance Today</th>
                    <th className="pb-3 font-medium">Pending Fees</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {[
                    { cls: "Class 10", sec: "A, B, C", stu: 112, att: "94%", fee: "12" },
                    { cls: "Class 9", sec: "A, B, C", stu: 118, att: "91%", fee: "18" },
                    { cls: "Class 8", sec: "A, B, C, D", stu: 145, att: "96%", fee: "9" },
                    { cls: "Class 7", sec: "A, B, C", stu: 126, att: "93%", fee: "15" },
                    { cls: "Class 6", sec: "A, B, C", stu: 131, att: "95%", fee: "11" },
                  ].map((row, i) => (
                    <tr key={i} className="hover:bg-slate-50">
                      <td className="py-3 font-medium text-slate-800">{row.cls}</td>
                      <td className="py-3 text-slate-600">{row.sec}</td>
                      <td className="py-3 text-slate-600">{row.stu}</td>
                      <td className="py-3">
                        <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded text-xs font-medium">
                          {row.att}
                        </span>
                      </td>
                      <td className="py-3 text-slate-600">{row.fee} students</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
