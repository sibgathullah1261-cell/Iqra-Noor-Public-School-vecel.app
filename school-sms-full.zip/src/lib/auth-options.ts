import type { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { verifyCredentials, demoLogin } from "@/lib/auth";

/**
 * NextAuth configuration — Credentials provider with role-based sessions.
 * Works with existing Prisma users + demo fallback.
 */
export const authOptions: NextAuthOptions = {
  session: {
    strategy: "jwt",
    maxAge: 7 * 24 * 60 * 60, // 7 days
  },
  pages: {
    signIn: "/login",
    error: "/login",
  },
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
        role: { label: "Role", type: "text" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null;

        let user = await verifyCredentials(
          credentials.email,
          credentials.password
        );
        if (!user) {
          user = demoLogin(
            credentials.email,
            credentials.password,
            credentials.role
          );
        }
        if (!user) return null;

        if (
          credentials.role &&
          user.role.toLowerCase() !== String(credentials.role).toLowerCase()
        ) {
          return null;
        }

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          studentId: user.studentId,
          teacherId: user.teacherId,
          parentId: user.parentId,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.role = (user as any).role;
        token.studentId = (user as any).studentId;
        token.teacherId = (user as any).teacherId;
        token.parentId = (user as any).parentId;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as any).id = token.sub;
        (session.user as any).role = token.role;
        (session.user as any).studentId = token.studentId;
        (session.user as any).teacherId = token.teacherId;
        (session.user as any).parentId = token.parentId;
      }
      return session;
    },
  },
  secret: process.env.NEXTAUTH_SECRET,
};
