/**
 * File storage abstraction.
 * STORAGE_PROVIDER=local | s3 | cloudinary
 *
 * Local: public/uploads (default for demo)
 * S3: needs AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, S3_BUCKET, S3_REGION
 * Cloudinary: needs CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET
 */

import { writeFile, mkdir } from "fs/promises";
import path from "path";
import crypto from "crypto";

export type StoredFile = {
  url: string;
  key: string;
  provider: string;
  size: number;
  contentType: string;
};

function randomName(ext: string) {
  return `${Date.now()}-${crypto.randomBytes(8).toString("hex")}.${ext}`;
}

function extFromType(type: string) {
  if (type === "application/pdf") return "pdf";
  if (type === "image/png") return "png";
  if (type === "image/webp") return "webp";
  return "jpg";
}

async function storeLocal(
  buffer: Buffer,
  contentType: string,
  category: string
): Promise<StoredFile> {
  const ext = extFromType(contentType);
  const filename = randomName(ext);
  const safeCat = category.replace(/[^a-z0-9_-]/gi, "").slice(0, 32) || "general";
  const dir = path.join(process.cwd(), "public", "uploads", safeCat);
  await mkdir(dir, { recursive: true });
  await writeFile(path.join(dir, filename), buffer);
  const key = `${safeCat}/${filename}`;
  return {
    url: `/uploads/${key}`,
    key,
    provider: "local",
    size: buffer.length,
    contentType,
  };
}

async function storeS3(
  buffer: Buffer,
  contentType: string,
  category: string
): Promise<StoredFile> {
  const bucket = process.env.S3_BUCKET;
  const region = process.env.S3_REGION || "ap-south-1";
  if (!bucket || !process.env.AWS_ACCESS_KEY_ID) {
    throw new Error("S3 not configured");
  }

  const ext = extFromType(contentType);
  const key = `${category}/${randomName(ext)}`;

  // Dynamic import so the app runs without AWS SDK installed
  try {
    const { S3Client, PutObjectCommand } = await import("@aws-sdk/client-s3");
    const client = new S3Client({ region });
    await client.send(
      new PutObjectCommand({
        Bucket: bucket,
        Key: key,
        Body: buffer,
        ContentType: contentType,
        ACL: "private",
      })
    );
    const url =
      process.env.S3_PUBLIC_URL ||
      `https://${bucket}.s3.${region}.amazonaws.com/${key}`;
    return { url, key, provider: "s3", size: buffer.length, contentType };
  } catch (e) {
    console.warn("S3 upload failed, falling back to local:", e);
    return storeLocal(buffer, contentType, category);
  }
}

async function storeCloudinary(
  buffer: Buffer,
  contentType: string,
  category: string
): Promise<StoredFile> {
  const cloud = process.env.CLOUDINARY_CLOUD_NAME;
  const apiKey = process.env.CLOUDINARY_API_KEY;
  const apiSecret = process.env.CLOUDINARY_API_SECRET;
  if (!cloud || !apiKey || !apiSecret) {
    throw new Error("Cloudinary not configured");
  }

  const b64 = buffer.toString("base64");
  const dataUri = `data:${contentType};base64,${b64}`;
  const folder = `school-sms/${category}`;

  const form = new URLSearchParams();
  form.set("file", dataUri);
  form.set("folder", folder);
  form.set("api_key", apiKey);
  const timestamp = Math.floor(Date.now() / 1000);
  form.set("timestamp", String(timestamp));

  // Signature: folder + timestamp + api_secret (simplified)
  const toSign = `folder=${folder}&timestamp=${timestamp}${apiSecret}`;
  const signature = crypto.createHash("sha1").update(toSign).digest("hex");
  form.set("signature", signature);

  const res = await fetch(
    `https://api.cloudinary.com/v1_1/${cloud}/auto/upload`,
    { method: "POST", body: form }
  );
  if (!res.ok) {
    throw new Error(`Cloudinary upload failed: ${res.status}`);
  }
  const data = await res.json();
  return {
    url: data.secure_url,
    key: data.public_id,
    provider: "cloudinary",
    size: buffer.length,
    contentType,
  };
}

export async function storeFile(
  buffer: Buffer,
  contentType: string,
  category = "general"
): Promise<StoredFile> {
  const provider = (process.env.STORAGE_PROVIDER || "local").toLowerCase();

  if (provider === "s3") {
    try {
      return await storeS3(buffer, contentType, category);
    } catch {
      return storeLocal(buffer, contentType, category);
    }
  }

  if (provider === "cloudinary") {
    try {
      return await storeCloudinary(buffer, contentType, category);
    } catch (e) {
      console.warn("Cloudinary failed, using local:", e);
      return storeLocal(buffer, contentType, category);
    }
  }

  return storeLocal(buffer, contentType, category);
}
