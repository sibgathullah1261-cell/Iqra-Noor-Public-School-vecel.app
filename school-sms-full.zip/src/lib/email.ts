/**
 * Email service — nodemailer when SMTP is configured, otherwise logs (demo).
 */

type EmailPayload = {
  to: string;
  subject: string;
  text: string;
  html?: string;
};

export async function sendEmail(payload: EmailPayload): Promise<boolean> {
  const host = process.env.SMTP_HOST;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  const from = process.env.EMAIL_FROM || "noreply@stxaviers.edu";
  const port = Number(process.env.SMTP_PORT || 587);

  if (!host || !user || !pass) {
    console.log("[email:demo]", {
      from,
      to: payload.to,
      subject: payload.subject,
      preview: payload.text.slice(0, 100),
    });
    return true;
  }

  try {
    const nodemailer = await import("nodemailer");
    const transporter = nodemailer.createTransport({
      host,
      port,
      secure: port === 465,
      auth: { user, pass },
    });

    await transporter.sendMail({
      from,
      to: payload.to,
      subject: payload.subject,
      text: payload.text,
      html: payload.html || payload.text.replace(/\n/g, "<br/>"),
    });
    return true;
  } catch (err) {
    console.error("[email] send failed:", err);
    return false;
  }
}

export async function sendAbsenceEmail(
  parentEmail: string,
  studentName: string,
  date: string
) {
  return sendEmail({
    to: parentEmail,
    subject: `Absence notification – ${studentName}`,
    text: `Dear Parent,\n\nThis is to inform you that ${studentName} was marked absent on ${date}.\n\nPlease contact the school if this is incorrect.\n\nRegards,\nSt. Xavier's High School`,
  });
}

export async function sendFeeReminder(
  parentEmail: string,
  studentName: string,
  amount: number,
  dueDate: string
) {
  return sendEmail({
    to: parentEmail,
    subject: `Fee reminder – ${studentName}`,
    text: `Dear Parent,\n\nA fee of ₹${amount} for ${studentName} is due on ${dueDate}.\nPlease log in to the Parent Portal to pay online.\n\nRegards,\nSt. Xavier's High School`,
  });
}

export async function sendAdmissionStatusEmail(
  email: string,
  applicantName: string,
  status: string,
  applicationNumber: string
) {
  return sendEmail({
    to: email,
    subject: `Admission application ${status} – ${applicationNumber}`,
    text: `Dear Parent,\n\nThe application for ${applicantName} (${applicationNumber}) has been ${status}.\n\nPlease check the school portal or contact admissions for next steps.\n\nRegards,\nSt. Xavier's High School`,
  });
}
