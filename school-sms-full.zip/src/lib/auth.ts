import bcrypt from "bcryptjs";
import { prisma } from "./prisma";
import { Role } from "@prisma/client";

export type SessionUser = {
  id: string;
  email: string;
  role: Role;
  name: string;
  studentId?: string;
  teacherId?: string;
  parentId?: string;
};

export async function verifyCredentials(
  email: string,
  password: string
): Promise<SessionUser | null> {
  try {
    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase().trim() },
      include: {
        adminProfile: true,
        teacher: true,
        student: true,
        parent: true,
      },
    });

    if (!user || !user.isActive) return null;

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) return null;

    // Update last login
    await prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    let name = user.email;
    if (user.adminProfile) name = user.adminProfile.fullName;
    else if (user.teacher) name = `${user.teacher.firstName} ${user.teacher.lastName}`;
    else if (user.student) name = `${user.student.firstName} ${user.student.lastName}`;
    else if (user.parent) name = user.parent.fatherName || user.parent.motherName || user.parent.guardianName || "Parent";

    return {
      id: user.id,
      email: user.email,
      role: user.role,
      name,
      studentId: user.student?.id,
      teacherId: user.teacher?.id,
      parentId: user.parent?.id,
    };
  } catch (err) {
    // If DB is not ready, return null so UI can fall back to demo mode
    console.warn("Auth DB lookup failed (is the database seeded?):", err);
    return null;
  }
}

/** Demo fallback when database is not seeded yet */
export function demoLogin(
  email: string,
  password: string,
  roleHint?: string
): SessionUser | null {
  const demos: Record<string, { password: string; role: Role; name: string }> = {
    "admin@stxaviers.edu": { password: "admin123", role: Role.ADMIN, name: "System Administrator" },
    "teacher@stxaviers.edu": { password: "teacher123", role: Role.TEACHER, name: "Anjali Mehta" },
    "student@stxaviers.edu": { password: "student123", role: Role.STUDENT, name: "Aarav Sharma" },
    "parent@stxaviers.edu": { password: "parent123", role: Role.PARENT, name: "Rajesh Sharma" },
  };

  const entry = demos[email.toLowerCase()];
  if (!entry || entry.password !== password) return null;
  if (roleHint && entry.role.toLowerCase() !== roleHint.toLowerCase()) return null;

  return {
    id: `demo-${entry.role.toLowerCase()}`,
    email,
    role: entry.role,
    name: entry.name,
  };
}
