/**
 * Client-side binary PDF generation using jsPDF.
 * Use from browser components after dynamic import.
 */

export type ReportCardData = {
  studentName: string;
  admissionNumber: string;
  className: string;
  section: string;
  rollNumber: string | number;
  examName: string;
  academicYear: string;
  subjects: { name: string; max: number; obtained: number; grade: string }[];
  percentage: number;
  overallGrade: string;
};

export async function downloadReportCardPDF(data: ReportCardData) {
  const { jsPDF } = await import("jspdf");
  // @ts-expect-error optional plugin
  await import("jspdf-autotable");

  const doc = new jsPDF();
  const pageW = doc.internal.pageSize.getWidth();

  // Header
  doc.setFillColor(30, 58, 95);
  doc.rect(0, 0, pageW, 36, "F");
  doc.setTextColor(201, 162, 39);
  doc.setFontSize(16);
  doc.text("St. Xavier's High School", pageW / 2, 16, { align: "center" });
  doc.setFontSize(9);
  doc.setTextColor(255, 255, 255);
  doc.text(
    "123 Education Lane, Knowledge City · +91-22-1234-5678",
    pageW / 2,
    26,
    { align: "center" }
  );

  doc.setTextColor(30, 58, 95);
  doc.setFontSize(13);
  doc.text("PROGRESS REPORT CARD", pageW / 2, 48, { align: "center" });
  doc.setFontSize(10);
  doc.setTextColor(100);
  doc.text(`${data.examName} · ${data.academicYear}`, pageW / 2, 56, {
    align: "center",
  });

  doc.setTextColor(30, 40, 60);
  doc.setFontSize(10);
  let y = 68;
  const meta = [
    `Student: ${data.studentName}`,
    `Admission No: ${data.admissionNumber}`,
    `Class: ${data.className}-${data.section}`,
    `Roll No: ${data.rollNumber}`,
  ];
  meta.forEach((line, i) => {
    doc.text(line, i % 2 === 0 ? 14 : pageW / 2, y + Math.floor(i / 2) * 7);
  });
  y += 20;

  const totalMax = data.subjects.reduce((s, x) => s + x.max, 0);
  const totalObt = data.subjects.reduce((s, x) => s + x.obtained, 0);

  // @ts-expect-error autotable
  doc.autoTable({
    startY: y,
    head: [["Subject", "Max", "Obtained", "Grade"]],
    body: [
      ...data.subjects.map((s) => [s.name, s.max, s.obtained, s.grade]),
      ["Total", totalMax, totalObt, `${data.percentage}%`],
    ],
    theme: "grid",
    headStyles: { fillColor: [30, 58, 95], textColor: 255 },
    styles: { fontSize: 9 },
  });

  // @ts-expect-error
  y = (doc.lastAutoTable?.finalY || y + 60) + 12;
  doc.setFontSize(11);
  doc.setTextColor(30, 58, 95);
  doc.text(
    `Overall: ${data.percentage}%  |  Grade: ${data.overallGrade}  |  Result: ${
      data.percentage >= 40 ? "PASS" : "FAIL"
    }`,
    14,
    y
  );

  y += 30;
  doc.setFontSize(9);
  doc.setTextColor(100);
  doc.text("Class Teacher", 30, y);
  doc.text("Principal", pageW - 50, y);
  doc.line(20, y - 8, 70, y - 8);
  doc.line(pageW - 70, y - 8, pageW - 20, y - 8);

  doc.setFontSize(8);
  doc.text(
    `Issued: ${new Date().toLocaleDateString("en-IN")} · Computer-generated official document`,
    pageW / 2,
    285,
    { align: "center" }
  );

  doc.save(`ReportCard-${data.admissionNumber}.pdf`);
}

export async function downloadFeeReceiptPDF(opts: {
  receiptNumber: string;
  studentName: string;
  admissionNumber: string;
  className: string;
  items: { name: string; amount: number }[];
  paymentMethod: string;
  transactionId?: string;
}) {
  const { jsPDF } = await import("jspdf");
  // @ts-expect-error
  await import("jspdf-autotable");

  const doc = new jsPDF();
  const pageW = doc.internal.pageSize.getWidth();
  const total = opts.items.reduce((s, i) => s + i.amount, 0);

  doc.setFillColor(30, 58, 95);
  doc.rect(0, 0, pageW, 32, "F");
  doc.setTextColor(201, 162, 39);
  doc.setFontSize(14);
  doc.text("St. Xavier's High School", pageW / 2, 14, { align: "center" });
  doc.setFontSize(8);
  doc.setTextColor(255, 255, 255);
  doc.text("Fee Payment Receipt", pageW / 2, 24, { align: "center" });

  doc.setTextColor(30, 40, 60);
  doc.setFontSize(10);
  let y = 44;
  [
    `Receipt No: ${opts.receiptNumber}`,
    `Date: ${new Date().toLocaleDateString("en-IN")}`,
    `Student: ${opts.studentName} (${opts.admissionNumber})`,
    `Class: ${opts.className}`,
    `Mode: ${opts.paymentMethod}`,
    opts.transactionId ? `Txn: ${opts.transactionId}` : "",
  ]
    .filter(Boolean)
    .forEach((line) => {
      doc.text(line, 14, y);
      y += 7;
    });

  // @ts-expect-error
  doc.autoTable({
    startY: y + 4,
    head: [["Particulars", "Amount (₹)"]],
    body: [
      ...opts.items.map((i) => [i.name, i.amount.toLocaleString("en-IN")]),
      ["Total", total.toLocaleString("en-IN")],
    ],
    theme: "grid",
    headStyles: { fillColor: [30, 58, 95] },
    styles: { fontSize: 9 },
  });

  doc.setFontSize(8);
  doc.setTextColor(120);
  doc.text(
    "This is a computer-generated receipt. For queries contact accounts office.",
    pageW / 2,
    280,
    { align: "center" }
  );

  doc.save(`FeeReceipt-${opts.receiptNumber}.pdf`);
}
