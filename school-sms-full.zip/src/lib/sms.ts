/**
 * SMS / WhatsApp notification stub.
 *
 * Supported providers via env:
 *   SMS_PROVIDER=twilio | msg91 | console
 *
 * Twilio:
 *   TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM_NUMBER
 *
 * MSG91 (India):
 *   MSG91_AUTH_KEY, MSG91_SENDER_ID, MSG91_TEMPLATE_ID
 *
 * WhatsApp (Twilio or Meta) can use the same interface later.
 */

export async function sendSMS(
  to: string,
  message: string
): Promise<{ success: boolean; provider: string; id?: string }> {
  const provider = (process.env.SMS_PROVIDER || "console").toLowerCase();
  const phone = to.replace(/\s+/g, "");

  if (provider === "twilio") {
    const sid = process.env.TWILIO_ACCOUNT_SID;
    const token = process.env.TWILIO_AUTH_TOKEN;
    const from = process.env.TWILIO_FROM_NUMBER;
    if (!sid || !token || !from) {
      console.log("[sms:twilio-missing-config]", { to: phone, message });
      return { success: true, provider: "console" };
    }
    try {
      const auth = Buffer.from(`${sid}:${token}`).toString("base64");
      const body = new URLSearchParams({ To: phone, From: from, Body: message });
      const res = await fetch(
        `https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`,
        {
          method: "POST",
          headers: {
            Authorization: `Basic ${auth}`,
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body,
        }
      );
      const data = await res.json();
      if (!res.ok) {
        console.error("[sms:twilio]", data);
        return { success: false, provider: "twilio" };
      }
      return { success: true, provider: "twilio", id: data.sid };
    } catch (e) {
      console.error("[sms:twilio]", e);
      return { success: false, provider: "twilio" };
    }
  }

  if (provider === "msg91") {
    const key = process.env.MSG91_AUTH_KEY;
    const sender = process.env.MSG91_SENDER_ID || "SXVHS";
    if (!key) {
      console.log("[sms:msg91-missing-config]", { to: phone, message });
      return { success: true, provider: "console" };
    }
    try {
      const res = await fetch("https://control.msg91.com/api/v5/flow/", {
        method: "POST",
        headers: {
          authkey: key,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          template_id: process.env.MSG91_TEMPLATE_ID,
          short_url: "0",
          recipients: [{ mobiles: phone.replace("+", ""), message }],
          sender,
        }),
      });
      const data = await res.json();
      return { success: res.ok, provider: "msg91", id: data.request_id };
    } catch (e) {
      console.error("[sms:msg91]", e);
      return { success: false, provider: "msg91" };
    }
  }

  // Default: log only
  console.log("[sms:console]", { to: phone, message: message.slice(0, 160) });
  return { success: true, provider: "console" };
}

export async function sendAbsenceSMS(
  parentPhone: string,
  studentName: string,
  date: string
) {
  return sendSMS(
    parentPhone,
    `St. Xavier's: ${studentName} was marked ABSENT on ${date}. Contact school if incorrect.`
  );
}

export async function sendFeeDueSMS(
  parentPhone: string,
  studentName: string,
  amount: number
) {
  return sendSMS(
    parentPhone,
    `St. Xavier's: Fee of Rs.${amount} pending for ${studentName}. Pay via Parent Portal.`
  );
}
