import crypto from "crypto";
import { cookies } from "next/headers";
import type { Role } from "@prisma/client";

const COOKIE_NAME = "sms_session";
const MAX_AGE = 60 * 60 * 24 * 7; // 7 days

export type SessionPayload = {
  id: string;
  email: string;
  role: Role | string;
  name: string;
  studentId?: string;
  teacherId?: string;
  parentId?: string;
  exp: number;
};

function getSecret() {
  return process.env.NEXTAUTH_SECRET || process.env.SESSION_SECRET || "school-sms-dev-secret-change-me";
}

function sign(data: string): string {
  return crypto.createHmac("sha256", getSecret()).update(data).digest("hex");
}

export function encodeSession(payload: Omit<SessionPayload, "exp">): string {
  const full: SessionPayload = {
    ...payload,
    exp: Math.floor(Date.now() / 1000) + MAX_AGE,
  };
  const body = Buffer.from(JSON.stringify(full)).toString("base64url");
  const sig = sign(body);
  return `${body}.${sig}`;
}

export function decodeSession(token: string | undefined | null): SessionPayload | null {
  if (!token) return null;
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  if (sign(body) !== sig) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8")) as SessionPayload;
    if (!payload.exp || payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch {
    return null;
  }
}

/** Server-side: read session from cookies */
export async function getServerSession(): Promise<SessionPayload | null> {
  try {
    const jar = await cookies();
    const token = jar.get(COOKIE_NAME)?.value;
    return decodeSession(token);
  } catch {
    return null;
  }
}

export function sessionCookieOptions(token: string) {
  return {
    name: COOKIE_NAME,
    value: token,
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax" as const,
    path: "/",
    maxAge: MAX_AGE,
  };
}

export function clearSessionCookie() {
  return {
    name: COOKIE_NAME,
    value: "",
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax" as const,
    path: "/",
    maxAge: 0,
  };
}

export function requireRole(session: SessionPayload | null, roles: string[]): SessionPayload {
  if (!session) {
    const err = new Error("Unauthorized");
    (err as any).status = 401;
    throw err;
  }
  const role = String(session.role).toUpperCase();
  if (!roles.map((r) => r.toUpperCase()).includes(role)) {
    const err = new Error("Forbidden");
    (err as any).status = 403;
    throw err;
  }
  return session;
}
