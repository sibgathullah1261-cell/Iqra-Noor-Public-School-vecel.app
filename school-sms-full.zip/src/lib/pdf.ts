/**
 * Official document helpers.
 * Generates print-ready HTML that can be converted to PDF
 * via browser print or a PDF library (puppeteer / @react-pdf).
 */

export type SchoolInfo = {
  name: string;
  address: string;
  phone: string;
  email: string;
};

export const defaultSchool: SchoolInfo = {
  name: "St. Xavier's High School",
  address: "123 Education Lane, Knowledge City, Maharashtra - 400001",
  phone: "+91-22-1234-5678",
  email: "info@stxaviers.edu",
};

export function reportCardHTML(opts: {
  school?: SchoolInfo;
  studentName: string;
  admissionNumber: string;
  className: string;
  section: string;
  rollNumber: string | number;
  examName: string;
  academicYear: string;
  subjects: { name: string; max: number; obtained: number; grade: string }[];
  percentage: number;
  overallGrade: string;
  issueDate?: string;
}) {
  const school = opts.school || defaultSchool;
  const totalMax = opts.subjects.reduce((s, x) => s + x.max, 0);
  const totalObt = opts.subjects.reduce((s, x) => s + x.obtained, 0);
  const date = opts.issueDate || new Date().toLocaleDateString("en-IN");

  const rows = opts.subjects
    .map(
      (s) => `
    <tr>
      <td style="padding:8px 12px;border:1px solid #cbd5e1;">${s.name}</td>
      <td style="padding:8px 12px;border:1px solid #cbd5e1;text-align:center;">${s.max}</td>
      <td style="padding:8px 12px;border:1px solid #cbd5e1;text-align:center;">${s.obtained}</td>
      <td style="padding:8px 12px;border:1px solid #cbd5e1;text-align:center;font-weight:600;">${s.grade}</td>
    </tr>`
    )
    .join("");

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>Report Card - ${opts.studentName}</title>
  <style>
    body { font-family: Georgia, 'Times New Roman', serif; color: #0f172a; margin: 0; padding: 32px; }
    .header { text-align: center; border-bottom: 3px solid #1e3a5f; padding-bottom: 16px; margin-bottom: 24px; }
    .logo { width: 64px; height: 64px; background: #1e3a5f; color: #c9a227; border-radius: 50%;
            display: inline-flex; align-items: center; justify-content: center; font-weight: bold; font-size: 20px;
            border: 3px solid #c9a227; margin-bottom: 8px; }
    h1 { margin: 0; color: #1e3a5f; font-size: 22px; }
    .sub { color: #64748b; font-size: 12px; margin-top: 4px; }
    h2 { text-align: center; color: #1e3a5f; font-size: 16px; letter-spacing: 1px;
         text-transform: uppercase; margin: 20px 0; }
    .meta { display: grid; grid-template-columns: 1fr 1fr; gap: 8px 24px; font-size: 13px; margin-bottom: 20px; }
    .meta strong { color: #1e3a5f; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    th { background: #1e3a5f; color: white; padding: 10px 12px; text-align: left; }
    .summary { margin-top: 20px; padding: 12px 16px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; }
    .footer { margin-top: 48px; display: flex; justify-content: space-between; font-size: 12px; color: #64748b; }
    .sign { text-align: center; min-width: 140px; }
    .sign-line { border-top: 1px solid #94a3b8; margin-top: 48px; padding-top: 6px; }
    @media print { body { padding: 16px; } }
  </style>
</head>
<body>
  <div class="header">
    <div class="logo">SX</div>
    <h1>${school.name}</h1>
    <div class="sub">${school.address}</div>
    <div class="sub">Tel: ${school.phone} · ${school.email}</div>
  </div>

  <h2>Progress Report Card</h2>
  <div style="text-align:center;font-size:13px;color:#64748b;margin-bottom:16px;">
    ${opts.examName} · Academic Year ${opts.academicYear}
  </div>

  <div class="meta">
    <div><strong>Student:</strong> ${opts.studentName}</div>
    <div><strong>Admission No:</strong> ${opts.admissionNumber}</div>
    <div><strong>Class / Section:</strong> ${opts.className} - ${opts.section}</div>
    <div><strong>Roll No:</strong> ${opts.rollNumber}</div>
  </div>

  <table>
    <thead>
      <tr>
        <th>Subject</th>
        <th style="text-align:center;">Max Marks</th>
        <th style="text-align:center;">Marks Obtained</th>
        <th style="text-align:center;">Grade</th>
      </tr>
    </thead>
    <tbody>
      ${rows}
      <tr style="font-weight:bold;background:#f1f5f9;">
        <td style="padding:8px 12px;border:1px solid #cbd5e1;">Total</td>
        <td style="padding:8px 12px;border:1px solid #cbd5e1;text-align:center;">${totalMax}</td>
        <td style="padding:8px 12px;border:1px solid #cbd5e1;text-align:center;">${totalObt}</td>
        <td style="padding:8px 12px;border:1px solid #cbd5e1;text-align:center;">${opts.percentage}%</td>
      </tr>
    </tbody>
  </table>

  <div class="summary">
    <strong>Overall Percentage:</strong> ${opts.percentage}% &nbsp;|&nbsp;
    <strong>Grade:</strong> ${opts.overallGrade} &nbsp;|&nbsp;
    <strong>Result:</strong> ${opts.percentage >= 40 ? "PASS" : "FAIL"}
  </div>

  <div class="footer">
    <div class="sign">
      <div class="sign-line">Class Teacher</div>
    </div>
    <div style="text-align:center;padding-top:48px;">
      Date of Issue: ${date}
    </div>
    <div class="sign">
      <div class="sign-line">Principal</div>
    </div>
  </div>
</body>
</html>`;
}

export function feeReceiptHTML(opts: {
  school?: SchoolInfo;
  receiptNumber: string;
  studentName: string;
  admissionNumber: string;
  className: string;
  items: { name: string; amount: number }[];
  paymentMethod: string;
  paymentDate?: string;
  transactionId?: string;
}) {
  const school = opts.school || defaultSchool;
  const total = opts.items.reduce((s, i) => s + i.amount, 0);
  const date = opts.paymentDate || new Date().toLocaleDateString("en-IN");

  const rows = opts.items
    .map(
      (i) => `
    <tr>
      <td style="padding:8px 12px;border:1px solid #cbd5e1;">${i.name}</td>
      <td style="padding:8px 12px;border:1px solid #cbd5e1;text-align:right;">₹${i.amount.toLocaleString("en-IN")}</td>
    </tr>`
    )
    .join("");

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>Fee Receipt - ${opts.receiptNumber}</title>
  <style>
    body { font-family: Georgia, serif; color: #0f172a; margin: 0; padding: 32px; }
    .header { text-align: center; border-bottom: 3px solid #1e3a5f; padding-bottom: 16px; margin-bottom: 24px; }
    .logo { width: 56px; height: 56px; background: #1e3a5f; color: #c9a227; border-radius: 50%;
            display: inline-flex; align-items: center; justify-content: center; font-weight: bold;
            border: 3px solid #c9a227; margin-bottom: 8px; }
    h1 { margin: 0; color: #1e3a5f; font-size: 20px; }
    .sub { color: #64748b; font-size: 12px; }
    h2 { text-align: center; color: #1e3a5f; letter-spacing: 1px; text-transform: uppercase; font-size: 15px; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 16px; }
    th { background: #1e3a5f; color: white; padding: 10px 12px; text-align: left; }
    .meta { font-size: 13px; margin: 16px 0; line-height: 1.7; }
    .total { font-size: 16px; font-weight: bold; text-align: right; margin-top: 12px; color: #1e3a5f; }
    .footer { margin-top: 40px; font-size: 11px; color: #64748b; text-align: center; border-top: 1px solid #e2e8f0; padding-top: 12px; }
    @media print { body { padding: 16px; } }
  </style>
</head>
<body>
  <div class="header">
    <div class="logo">SX</div>
    <h1>${school.name}</h1>
    <div class="sub">${school.address}</div>
    <div class="sub">${school.phone} · ${school.email}</div>
  </div>
  <h2>Fee Payment Receipt</h2>
  <div class="meta">
    <div><strong>Receipt No:</strong> ${opts.receiptNumber}</div>
    <div><strong>Date:</strong> ${date}</div>
    <div><strong>Student:</strong> ${opts.studentName} (${opts.admissionNumber})</div>
    <div><strong>Class:</strong> ${opts.className}</div>
    <div><strong>Payment Mode:</strong> ${opts.paymentMethod}</div>
    ${opts.transactionId ? `<div><strong>Transaction ID:</strong> ${opts.transactionId}</div>` : ""}
  </div>
  <table>
    <thead><tr><th>Particulars</th><th style="text-align:right;">Amount</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>
  <div class="total">Total Paid: ₹${total.toLocaleString("en-IN")}</div>
  <div class="footer">
    This is a computer-generated receipt. For queries contact the school accounts office.<br/>
    ${school.name} · ${school.phone}
  </div>
</body>
</html>`;
}
