import { prisma } from "./prisma";
import { NotificationType } from "@prisma/client";

/**
 * Create an in-app notification for a user.
 * Designed so email / SMS / WhatsApp can be added later
 * without changing call sites.
 */
export async function notifyUser(opts: {
  userId: string;
  title: string;
  message: string;
  type?: NotificationType;
  link?: string;
}) {
  try {
    return await prisma.notification.create({
      data: {
        userId: opts.userId,
        title: opts.title,
        message: opts.message,
        type: opts.type || NotificationType.GENERAL,
        link: opts.link,
      },
    });
  } catch (err) {
    console.warn("Notification create skipped (DB?):", err);
    return null;
  }
}

/** Broadcast to all users of given roles (best-effort) */
export async function notifyRoles(
  roles: ("ADMIN" | "TEACHER" | "STUDENT" | "PARENT")[],
  title: string,
  message: string,
  type: NotificationType = NotificationType.ANNOUNCEMENT
) {
  try {
    const users = await prisma.user.findMany({
      where: { role: { in: roles }, isActive: true },
      select: { id: true },
    });
    if (users.length === 0) return 0;
    await prisma.notification.createMany({
      data: users.map((u) => ({
        userId: u.id,
        title,
        message,
        type,
      })),
    });
    return users.length;
  } catch {
    return 0;
  }
}
