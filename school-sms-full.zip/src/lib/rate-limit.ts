/**
 * Simple in-memory rate limiter (per process).
 * For multi-instance production use Redis or similar.
 */

type Bucket = { count: number; resetAt: number };

const buckets = new Map<string, Bucket>();

export function rateLimit(
  key: string,
  limit = 10,
  windowMs = 60_000
): { ok: boolean; remaining: number; retryAfterMs: number } {
  const now = Date.now();
  let b = buckets.get(key);
  if (!b || b.resetAt < now) {
    b = { count: 0, resetAt: now + windowMs };
    buckets.set(key, b);
  }
  b.count += 1;
  const remaining = Math.max(0, limit - b.count);
  if (b.count > limit) {
    return { ok: false, remaining: 0, retryAfterMs: b.resetAt - now };
  }
  return { ok: true, remaining, retryAfterMs: 0 };
}
